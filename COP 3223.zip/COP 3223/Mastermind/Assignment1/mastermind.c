//Due 9/12/21

#include <stdio.h>
#include <stdlib.h>
// preprocessor commands to include files from C library

void welcomeScreen();
void clearScreen();
void displayBoard();
// function declarations/prototypes, all void with empty parameter list

// main function calls all functions and returns 0
int main() {
    welcomeScreen();
    clearScreen();
    displayBoard();
    return 0;
}

// welcomeScreen function prints the Mastermind board
void welcomeScreen() {
    printf("\t\t############################################################\n");
    printf("\t\t############################################################\n");
    printf("\t\t############\t\t\t\t\t############\n");
    printf("\t\t############\t\t Mastermind\t\t############\n");
    printf("\t\t############\t\t\t\t\t############\n");
    printf("\t\t############################################################\n");
    printf("\t\t############################################################\n");
    /* Even though there isn't really a pattern to the way I wrote the
     * hashtags and tabs, when I run it, it displays in a visually appealing way.
     * I basically wrote it after a lot of adjusting so it displayed well. */
    printf("\tRules:\n");
    printf("\t1.\tThe Codemaker sets a secret code\n");
    printf("\t2.\tThe Codebreaker tries to match the code using logic and deduction\n");
    printf("\t3.\tAfter each move, the Codemaker gives clues to the Codebreaker\n");
    printf("\t4.\tThe Codebreaker has 10 attempts to guess the secret code\n");
    // I added a tab at the front of the rules because I personally think it looks a bit better.
}

// clearScreen function prompts the user to hit enter, scans their enter, and clears the system
void clearScreen() {
    printf("\n\t\t\t\t   <Hit Enter to continue>\n");
    char enter; // declares variable of datatype char
    scanf("%c", &enter); // reads user input
    system("cls"); // for windows users
    system("clear"); // for mac users
}

/* displayBoard function... does its titular action.
 * I added a tab in the beginning of all the lines for aesthetic purposes.
 * I wrote the rest after a lot of trial and error to visually replicate the assignment. */
void displayBoard() {
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|\t\t\tSECRET CODE\t\t\t |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|\t       \t?\t?\t?\t?\t\t |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|\t   PLAYER GUESS\t\t|\t   CLUES\t |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
}
