//Due 9/19/21

#include <stdio.h>
#include <stdlib.h>
// preprocessor commands to include files from C library
#include <time.h> // new addition of time.h library

const int COLORS = 8;
// global constant definition

void welcomeScreen();
void clearScreen();
void displayBoard();
// function declarations/prototypes, all void with empty parameter list
void setCode();
int getColor();
void convertColor(int color);
// new function declarations/prototypes for new functions

// enumeration for color with members
enum color {
    BLACK,
    GREEN,
    NAVY,
    ORANGE,
    PINK,
    RED,
    VIOLET,
    WHITE
};

// main function calls all functions and returns 0
int main() {
    srand(time(NULL)); //calls srand() with time(NULL) as its argument
    welcomeScreen();
    clearScreen();
    setCode();
    clearScreen();
    displayBoard();
    return 0;
} // all functions in correct order

// welcomeScreen function prints the Mastermind board
void welcomeScreen() {
    printf("\t\t############################################################\n");
    printf("\t\t############################################################\n");
    printf("\t\t############\t\t\t\t\t############\n");
    printf("\t\t############\t\t Mastermind\t\t############\n");
    printf("\t\t############\t\t\t\t\t############\n");
    printf("\t\t############################################################\n");
    printf("\t\t############################################################\n");
    /* Even though there isn't really a pattern to the way I wrote the
     * hashtags and tabs, when I run it, it displays in a visually appealing way.
     * I basically wrote it after a lot of adjusting so it displayed well. */
    printf("\tRules:\n");
    printf("\t1.\tThe Codemaker sets a secret code\n");
    printf("\t2.\tThe Codebreaker tries to match the code using logic and deduction\n");
    printf("\t3.\tAfter each move, the Codemaker gives clues to the Codebreaker\n");
    printf("\t4.\tThe Codebreaker has 10 attempts to guess the secret code\n");
    // I added a tab at the front of the rules because I personally think it looks a bit better.
}

// clearScreen function prompts the user to hit enter, scans their enter, and clears the system
void clearScreen() {
    printf("\n\t\t\t\t   <Hit Enter to continue>\n");
    char enter; // declares variable of datatype char
    scanf("%c", &enter); // reads user input
    system("cls"); // for windows users
    system("clear"); // for mac users
}

/* displayBoard function... does its titular action.
 * I added a tab in the beginning of all the lines for aesthetic purposes.
 * I wrote the rest after a lot of trial and error to visually replicate the assignment. */
void displayBoard() {
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|\t\t\tSECRET CODE\t\t\t |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|\t       \t?\t?\t?\t?\t\t |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|\t   PLAYER GUESS\t\t|\t   CLUES\t |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
}

// assignment 2 functions begin below

// prints out the code and color names
void setCode() {
    int color1 = getColor();
    int color2 = getColor();
    int color3 = getColor();
    int color4 = getColor();
    // variables for randomly selected enum colors, calling function getColor
    printf("Integer Secret Code:\n%d %d %d %d\n\n", color1, color2, color3, color4);
    // prints out the integers with new lines for formatting
    printf("Color Secret Code:\n");
    convertColor(color1);
    convertColor(color2);
    convertColor(color3);
    convertColor(color4);
    // calls convertColor 4 times for each color in the code
}

// gets random color from the range of enum members
int getColor() {
    int color;
    // i.e was used in the instructions so I just used that as the variable name
    color = (rand() % COLORS);
    /* using the % operation with a random number on the left and COLORS on the right
     * (the enumeration of which would be 8) ensures the return value of color will be
     * 8 digits within the range of 0-7 inclusive because it begins counting at 0 */
    return color;
}

// passes an integer as an parameter/argument (interchangeable for this specific function)
void convertColor(int color) {
    if (color == 0) {
        printf("Black ");
    }
    else if (color == 1) {
        printf("Green ");
    }
    else if (color == 2) {
        printf("Navy ");
    }
    else if (color == 3) {
        printf("Orange ");
    }
    else if (color == 4) {
        printf("Pink ");
    }
    else if (color == 5) {
        printf("Red ");
    }
    else if (color == 6) {
        printf("Violet ");
    }
    else {
        printf("White ");
    }
}
/* I used if/elseif/else statements as my decision making code.
 * I also made sure that the display was correct by adding a space after
 * each color. I checked and the print statements correspond correctly
 * with the members in enum color. */
