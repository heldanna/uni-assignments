//Due 9/30/21

#include <stdio.h>
#include <stdlib.h>
// preprocessor commands to include files from C library
#include <time.h> // addition of time.h library

#define COLORS 8
#define FOUR 4
#define TEN 10
#define TRUE 1
#define FALSE 0
// defining global constants

void welcomeScreen();
void clearScreen();
void displayBoard();
// function declarations/prototypes, all void with empty parameter list
void setCode(int codeArray[FOUR]);
// updated function declaration/prototype with integer array as argument
int getColor();
void convertColor(int color);
void populateColorArray(char colors[COLORS]);
// more function declarations/prototypes

// enumeration for color with members
enum color {
    BLACK,
    GREEN,
    NAVY,
    ORANGE,
    PINK,
    RED,
    VIOLET,
    WHITE
};

// main function calls all functions and returns 0
int main() {
    char colors[COLORS];
    int secretCode[FOUR];
    int guesses[TEN][FOUR];
    int clues[TEN][FOUR];
    // array declarations with constants for array sizes
    srand(time(NULL)); //calls srand() with time(NULL) as its argument
    welcomeScreen();
    clearScreen();
    setCode(secretCode); // passes array secretCode as argument
    clearScreen();
    displayBoard();
    populateColorArray(colors); // passes array colors as argument
    return 0;
}

// welcomeScreen function prints the Mastermind board
void welcomeScreen() {
    printf("\t\t############################################################\n");
    printf("\t\t############################################################\n");
    printf("\t\t############\t\t\t\t\t############\n");
    printf("\t\t############\t\t Mastermind\t\t############\n");
    printf("\t\t############\t\t\t\t\t############\n");
    printf("\t\t############################################################\n");
    printf("\t\t############################################################\n");
    /* Even though there isn't really a pattern to the way I wrote the
     * hashtags and tabs, when I run it, it displays in a visually appealing way.
     * I basically wrote it after a lot of adjusting so it displayed well. */
    printf("\tRules:\n");
    printf("\t1.\tThe Codemaker sets a secret code\n");
    printf("\t2.\tThe Codebreaker tries to match the code using logic and deduction\n");
    printf("\t3.\tAfter each move, the Codemaker gives clues to the Codebreaker\n");
    printf("\t4.\tThe Codebreaker has 10 attempts to guess the secret code\n");
    // I added a tab at the front of the rules because I personally think it looks a bit better.
}

// clearScreen function prompts the user to hit enter, scans their enter, and clears the system
void clearScreen() {
    printf("\n\t\t\t\t   <Hit Enter to continue>\n");
    char enter; // declares variable of datatype char
    scanf("%c", &enter); // reads user input
    system("cls"); // for windows users
    system("clear"); // for mac users
}

/* displayBoard function... does its titular action.
 * I added a tab in the beginning of all the lines for aesthetic purposes.
 * I wrote the rest after a lot of trial and error to visually replicate the assignment. */
void displayBoard() {
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|\t\t\tSECRET CODE\t\t\t |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|\t       \t?\t?\t?\t?\t\t |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|\t   PLAYER GUESS\t\t|\t   CLUES\t |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
    printf("\t|      ?     ?     ?     ?\t|    ?    ?    ?    ?    |\n");
    printf("\t+--------------------------------------------------------+\n");
}

// assignment 2 functions begin below

// prints out the code and color names
void setCode(int codeArray[FOUR]) {
    int i; // looping variable
    for (i = 0; i < FOUR; i++) {
    // loops 4 times, FOUR representing the size of the array
        codeArray[i] = getColor();
    } // loop to set elements of codeArray to getColor
    printf("Integer Secret Code:\n");
    for (i = 0; i < FOUR; i++) {
        printf("%d ", codeArray[i]);
    } // prints each number in the code
    printf("\nColor Secret Code:\n");
    for (i = 0; i < FOUR; i++) {
        convertColor(codeArray[i]);
    } // prints each corresponding color
}

// gets random color from the range of enum members
int getColor() {
    int color;
    // i.e was used in the instructions so I just used that as the variable name
    color = (rand() % COLORS);
    /* using the % operation with a random number on the left and COLORS on the right
     * (the enumeration of which would be 8) ensures the return value of color will be
     * 8 digits within the range of 0-7 inclusive because it begins counting at 0 */
    return color;
}

// passes an integer as an parameter/argument (interchangeable for this specific function)
void convertColor(int color) {
    if (color == 0) {
        printf("Black ");
    }
    else if (color == 1) {
        printf("Green ");
    }
    else if (color == 2) {
        printf("Navy ");
    }
    else if (color == 3) {
        printf("Orange ");
    }
    else if (color == 4) {
        printf("Pink ");
    }
    else if (color == 5) {
        printf("Red ");
    }
    else if (color == 6) {
        printf("Violet ");
    }
    else {
        printf("White ");
    }
}
/* I used if/elseif/else statements as my decision making code.
 * I also made sure that the display was correct by adding a space after
 * each color. I checked and the print statements correspond correctly
 * with the members in enum color. */

 void populateColorArray(char colors[COLORS]) {
     int color; // looping variable used in video example
     for (color = 0; color < COLORS; color++) {
     // loops 8 times because COLORS has the value 8
        if (color == 0) {
            colors[color] = 'B';
        } /* if the looping variable is on its first iteration,
        the character is B because black is the first color in the array.
        The same goes for the rest of the else if and else statements under the for loop */
        else if (color == 1) {
            colors[color] = 'G';
        }
        else if (color == 2) {
            colors[color] = 'N';
        }
        else if (color == 3) {
            colors[color] = 'O';
        }
        else if (color == 4) {
            colors[color] = 'P';
        }
        else if (color == 5) {
            colors[color] = 'R';
        }
        else if (color == 6) {
            colors[color] = 'V';
        }
        else {
            colors[color] = 'W';
        }
     }
     printf("\nCharacter colors are\n");
     for (color = 0; color < COLORS; color++) {
        printf("%c ", colors[color]);
     } // prints the character colors in a loop
 }
