//Due 10/31/21

#include <stdio.h>
#include <stdlib.h>
// preprocessor commands to include files from C library
#include <time.h> // addition of time.h library
#include <ctype.h>
#include <string.h>
// new preprocessor commands for mastermind4

#define COLORS 8
#define FOUR 4
#define TEN 10
#define TRUE 1
#define FALSE 0
// defining global constants
#define THREE 3
#define NINE 9
#define ZERO 0
#define INVALID -1

void welcomeScreen();
void clearScreen();
// function declarations/prototypes, all void with empty parameter list
void displayBoard(int guesses[TEN][FOUR], int clues[TEN][FOUR]);
// modified displayBoard function declaration/prototype
void setCode(int codeArray[FOUR]);
// updated function declaration/prototype with integer array as argument
int getColor();
void convertColor(int color);
void populateColorArray(char colors[COLORS]);
// more function declarations/prototypes
void initializeArray(int guesses[TEN][FOUR]);
void getGuess(int guesses[TEN][FOUR], char colors[COLORS]);
int isValid(char colors[COLORS], char color);
// assignment 4 function declarations/prototypes

// enumeration for color with members
enum color {
    BLACK,
    GREEN,
    NAVY,
    ORANGE,
    PINK,
    RED,
    VIOLET,
    WHITE
};

// main function calls all functions and returns 0
int main() {
    char colors[COLORS];
    int secretCode[FOUR];
    int guesses[TEN][FOUR];
    int clues[TEN][FOUR];
    // array declarations with constants for array sizes
    srand(time(NULL)); //calls srand() with time(NULL) as its argument
    welcomeScreen();
    clearScreen();
    setCode(secretCode); // passes array secretCode as argument
    clearScreen();
    populateColorArray(colors); // passes array colors as argument
    initializeArray(guesses);
    initializeArray(clues); // calls initializeArray again with clues as argument
    displayBoard(guesses, clues); // updated arguments for displayBoard
    int turn; // looping variable
    for (turn = ZERO; turn < TEN; turn++) { // loops 10 times
        getGuess(guesses, colors); // calls getGuess in loop
        displayBoard(guesses, clues); // calls displayBoard in loop
    }
    return 0;
}

// welcomeScreen function prints the Mastermind board
void welcomeScreen() {
    printf("\t\t############################################################\n");
    printf("\t\t############################################################\n");
    printf("\t\t############\t\t\t\t\t############\n");
    printf("\t\t############\t\t Mastermind\t\t############\n");
    printf("\t\t############\t\t\t\t\t############\n");
    printf("\t\t############################################################\n");
    printf("\t\t############################################################\n");
    /* Even though there isn't really a pattern to the way I wrote the
     * hashtags and tabs, when I run it, it displays in a visually appealing way.
     * I basically wrote it after a lot of adjusting so it displayed well. */
    printf("\tRules:\n");
    printf("\t1.\tThe Codemaker sets a secret code\n");
    printf("\t2.\tThe Codebreaker tries to match the code using logic and deduction\n");
    printf("\t3.\tAfter each move, the Codemaker gives clues to the Codebreaker\n");
    printf("\t4.\tThe Codebreaker has 10 attempts to guess the secret code\n");
    // I added a tab at the front of the rules because I personally think it looks a bit better.
}

// clearScreen function prompts the user to hit enter, scans their enter, and clears the system
void clearScreen() {
    printf("\n\t\t\t\t   <Hit Enter to continue>\n");
    char enter; // declares variable of datatype char
    scanf("%c", &enter); // reads user input
    system("cls"); // for windows users
    system("clear"); // for mac/linux users
}

/* displayBoard function... does its titular action.
 * I added a tab in the beginning of all the lines for aesthetic purposes.
 * I wrote the rest after a lot of trial and error to visually replicate the assignment. */
void displayBoard(int guesses[TEN][FOUR], int clues[TEN][FOUR]) {
    printf("\t+-------------------------------------------------------------------------------+\n");
    printf("\t|\t\t\t\t   SECRET CODE\t\t\t\t\t|\n");
    printf("\t+-------------------------------------------------------------------------------+\n");
    printf("\t|\t\t\t    ?\t    ?\t    ?\t    ?\t\t\t\t|\n");
    printf("\t+-------------------------------------------------------------------------------+\n");
    printf("\t|\t       PLAYER GUESS\t\t|\t\t  CLUES\t\t\t|\n");
    printf("\t+-------------------------------------------------------------------------------+\n");
    // first 7 statements still hardcoded
    int row = ZERO;
    int col = ZERO;
    // looping variables
    for (row = NINE; row >= ZERO; row--) {
    // since last guess is on top, loop goes "backwards"
        printf("\t|"); // prints tab and line for formatting
        for (col = ZERO; col < FOUR; col++) {
        // loops through each element of guesses array
            if(guesses[row][col] == INVALID) {
                printf("\t?");
            } // displays a question mark if value stored in array is invalid
            else {
                printf("\t%c", guesses[row][col]);
            } // displays character stored in array if value stored in array is valid
        }
        printf("\t|");
        for (col = ZERO; col < FOUR; col++) {
            if(clues[row][col] == INVALID) {
                printf("\t?");
            }
            else {
                printf("\t%c", clues[row][col]);
            }
        } // this loop does the same thing as that of the guesses one except for the clues
        printf("\t|\n\t+-------------------------------------------------------------------------------+\n");
    }
}

// prints out the code and color names
void setCode(int codeArray[FOUR]) {
    int i; // looping variable
    for (i = 0; i < FOUR; i++) {
    // loops 4 times, FOUR representing the size of the array
        codeArray[i] = getColor();
    } // loop to set elements of codeArray to getColor
    printf("Integer Secret Code:\n");
    for (i = 0; i < FOUR; i++) {
        printf("%d ", codeArray[i]);
    } // prints each number in the code
    printf("\n\nColor Secret Code:\n");
    for (i = 0; i < FOUR; i++) {
        convertColor(codeArray[i]);
    } // prints each corresponding color
}

// gets random color from the range of enum members
int getColor() {
    int color = (rand() % COLORS);
    /* using the % operation with a random number on the left and COLORS on the right
     * (the enumeration of which would be 8) ensures the return value of color will be
     * 8 digits within the range of 0-7 inclusive because it begins counting at 0 */
    return color;
}

// passes an integer as an parameter/argument (interchangeable for this specific function)
void convertColor(int color) {
    if (color == 0) {
        printf("Black ");
    }
    else if (color == 1) {
        printf("Green ");
    }
    else if (color == 2) {
        printf("Navy ");
    }
    else if (color == 3) {
        printf("Orange ");
    }
    else if (color == 4) {
        printf("Pink ");
    }
    else if (color == 5) {
        printf("Red ");
    }
    else if (color == 6) {
        printf("Violet ");
    }
    else {
        printf("White ");
    }
}
/* I used if/elseif/else statements as my decision making code.
 * I also made sure that the display was correct by adding a space after
 * each color. I checked and the print statements correspond correctly
 * with the members in enum color. */

 void populateColorArray(char colors[COLORS]) {
     int color; // looping variable used in video example
     for (color = 0; color < COLORS; color++) {
     // loops 8 times because COLORS has the value 8
        if (color == 0) {
            colors[color] = 'B';
        } /* if the looping variable is on its first iteration,
        the character is B because black is the first color in the array.
        The same goes for the rest of the else if and else statements under the for loop */
        else if (color == 1) {
            colors[color] = 'G';
        }
        else if (color == 2) {
            colors[color] = 'N';
        }
        else if (color == 3) {
            colors[color] = 'O';
        }
        else if (color == 4) {
            colors[color] = 'P';
        }
        else if (color == 5) {
            colors[color] = 'R';
        }
        else if (color == 6) {
            colors[color] = 'V';
        }
        else {
            colors[color] = 'W';
        }
     } /*
     printf("\nCharacter colors are\n");
     for (color = 0; color < COLORS; color++) {
        printf("%c ", colors[color]);
     } // prints the character colors in a loop
     // commenting out the console output of colors array elements */
 }

// sets each element of the guesses array to -1
void initializeArray(int guesses[TEN][FOUR]) {
// void with guesses array as parameter
    int row, col; // looping variables
    for (row = 0; row < TEN; row++) {
    // loops through rows of the array
        for (col = 0; col < FOUR; col++) {
        // loops through the array's columns
            guesses[row][col] = -1;
        }
    }
}

// iterates through guessing values until valid ones are entered
void getGuess(int guesses[TEN][FOUR], char colors[COLORS]) {
    static int row = 0;
    // static variable that stores row / turn of the game, initialized to 0
    int col; // stores current column
    int valid = FALSE; // stores validity of player's guess, initialized to global constant
    char guess[TEN]; // stores player's guess

    printf("\nCharacter colors are\n");
    for (col = 0; col < COLORS; col++) {
        printf("%c ", colors[col]);
    } // loop prints elements of array colors

    /* this massive loop only runs while the player's input isn't valid.
    once it is, the loop will cease and the following functions in the main will run. */
    while (valid == FALSE) {
        printf("\nEnter your guess of four colors (no spaces):\n");
        // prompts user to enter their guess in the correct format
        scanf("%s", guess); // stores user input into guess array
        printf("\nYou entered %s\n", guess); // prints user input onto console

        // loop only runs when the user's guess is the correct length of 4
        if (strlen(guess) == FOUR) {
            for (col = 0; col < FOUR; col++) {
            // loops for each character in user input
                guess[col] = toupper(guess[col]);
                // capitalizes all the characters
                if (isalpha(guess[col])) {
                // checks if the characters are all letters
                    if (isValid(colors, guess[col])) {
                    /* calls isValid function to see if the user-inputted letters
                    are part of the options in the colors array */
                        guesses[row][col] = guess[col];
                        // sets current row+column of guesses array to the column of the guess array
                        if (col == THREE) {
                            valid = TRUE;
                        } // if col's value is 3, valid is true
                    }
                    else {
                        printf("getGuess: Invalid value entered %c, try again\n", guess[col]);
                        valid = FALSE;
                        break;
                    } // output when the user enters a letter that isn't one of the options in the colors array
                }
                else {
                    printf("The character %c you entered isn't a letter, try again\n", guess[col]);
                    valid = FALSE;
                    break;
                } // output when the user enters a non-letter
            }
        }
        else {
            printf("getGuess: Incorrect number of letters entered\n");
            valid = FALSE;
        } // output when the user puts in any amount of letters or characters that isn't 4
    }

    row++; // increments static variable by 1
}

// checks if letters are part of the letter options in the colors array
int isValid(char colors[COLORS], char color) {
    int c; // looping variable
    int valid = FALSE; // initializes valid as false
    for (c = 0; c < COLORS; c++) {
        if (colors[c] == color) {
            return TRUE;
        } // returns true if all the letters match those in the colors array
    } // iterates through all the colors in the array
    return FALSE;
    // returns false if not all the letters match
}
