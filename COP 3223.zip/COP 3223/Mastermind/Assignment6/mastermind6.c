//Due 11/21/21

// preprocessor commands
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <string.h>

// global constant definitions
#define COLORS 8
#define FOUR 4
#define TEN 10
#define TRUE 1
#define FALSE 0
#define THREE 3
#define NINE 9
#define ZERO 0
#define INVALID -1

// function prototypes
void welcomeScreen();
void clearScreen();
void displayBoard(int guesses[TEN][FOUR], int clues[TEN][FOUR]);
void setCode(int codeArray[FOUR]);
int getColor();
void convertColor(int color);
void populateColorArray(char colors[COLORS]);
void initializeArray(int guesses[TEN][FOUR]);
void getGuess(int guesses[TEN][FOUR], char colors[COLORS]);
int isValid(char colors[COLORS], char color);
// final function declarations/prototypes
void getClues(int guesses[TEN][FOUR], int clues[TEN][FOUR], int secretCode[FOUR], char colors[COLORS]);
void evaluatePegs(int red, int white, int clues[TEN][FOUR]);
int searchArray(int guesses[TEN][FOUR], char color, int row);
int checkWin(int clues[TEN][FOUR]);
int isDuplicate(char guess[TEN]);

// enumeration for color with numbers
enum color {
    BLACK,
    GREEN,
    NAVY,
    ORANGE,
    PINK,
    RED,
    VIOLET,
    WHITE
};

int main() {
    int win; // added local variable to store if player has won
    char colors[COLORS];
    int secretCode[FOUR];
    int guesses[TEN][FOUR];
    int clues[TEN][FOUR];
    srand(time(NULL));
    welcomeScreen();
    clearScreen();
    setCode(secretCode);
    populateColorArray(colors);
    initializeArray(guesses);
    initializeArray(clues);
    displayBoard(guesses, clues);
    // loop that iterates for each turn of the game
    for (int turn = ZERO; turn < TEN; turn++) {
        getGuess(guesses, colors);
        getClues(guesses, clues, secretCode, colors);
        // calls function getClues with correct arguments
        displayBoard(guesses, clues);
        win = checkWin(clues); // equates win to checkWin passing argument clues
        int i; // looping variable
        if (win == TRUE) {
            printf("\nYou have guessed the secret code! Secret code:\n");
            for (i = ZERO; i < FOUR; i++) {
                convertColor(secretCode[i]);
            }
            return 0; // ends game after user has won
        } // prints that user guessed the secret code
        else if (win == FALSE && turn == NINE) {
            printf("\nSorry, you did not guess the secret code. It was actually\n");
            for (i = ZERO; i < FOUR; i++) {
                convertColor(secretCode[i]);
            }
        } // prints if the user has gone through all tries of the game
    }
    return 0;
}

// prints Figure 1 screen
void welcomeScreen() {
    printf("\t\t############################################################\n");
    printf("\t\t############################################################\n");
    printf("\t\t############\t\t\t\t\t############\n");
    printf("\t\t############\t\t Mastermind\t\t############\n");
    printf("\t\t############\t\t\t\t\t############\n");
    printf("\t\t############################################################\n");
    printf("\t\t############################################################\n");
    printf("\tRules:\n");
    printf("\t1.\tThe Codemaker sets a secret code\n");
    printf("\t2.\tThe Codebreaker tries to match the code using logic and deduction\n");
    printf("\t3.\tAfter each move, the Codemaker gives clues to the Codebreaker\n");
    printf("\t4.\tThe Codebreaker has 10 attempts to guess the secret code\n");
}

// prompts user to hit enter, scans their enter, and clears system
void clearScreen() {
    char enter;
    printf("\n\t\t\t\t   <Hit Enter to continue>\n");
    scanf("%c", &enter);
    system("cls"); // for windows users
    system("clear"); // for mac/linux users
}

// displays Figure 2 screen
void displayBoard(int guesses[TEN][FOUR], int clues[TEN][FOUR]) {
    printf("\t+-------------------------------------------------------------------------------+\n");
    printf("\t|\t\t\t\t   SECRET CODE\t\t\t\t\t|\n");
    printf("\t+-------------------------------------------------------------------------------+\n");
    printf("\t|\t\t\t    ?\t    ?\t    ?\t    ?\t\t\t\t|\n");
    printf("\t+-------------------------------------------------------------------------------+\n");
    printf("\t|\t       PLAYER GUESS\t\t|\t\t  CLUES\t\t\t|\n");
    printf("\t+-------------------------------------------------------------------------------+\n");
    int row;
    int col;
    for (row = NINE; row >= ZERO; row--) {
        printf("\t|");
        for (col = ZERO; col < FOUR; col++) {
            if(guesses[row][col] == INVALID) {
                printf("\t?");
            }
            else {
                printf("\t%c", guesses[row][col]);
            }
        }
        printf("\t|");
        for (col = ZERO; col < FOUR; col++) {
            if(clues[row][col] == INVALID) {
                printf("\t?");
            }
            else {
                printf("\t%c", clues[row][col]);
            }
        }
        printf("\t|\n\t+-------------------------------------------------------------------------------+\n");
    }
}

// sets the code for the user to guess
void setCode(int codeArray[FOUR]) {
// returns void and parameter list is an array of size 4
    int code;
    int isUsed[COLORS];
    const int USED = 1;
    // new local variables
    for (code = ZERO; code < COLORS; code++) {
        isUsed[code] = INVALID;
    }
    for (code = ZERO; code < FOUR; code++) {
        codeArray[code] = INVALID;
    }
    // for loops initialize all elements in both arrays to -1
    code = ZERO; // resets code variable to 0
    while (code < FOUR) { // loop runs 4 times
        int color = getColor(); // declares local variable to the function call getColor
        if (isUsed[color] == INVALID) { // checks if color in array isUsed is invalid
            isUsed[color] = USED; // change it to used
            codeArray[code] = color; // set the array at the code position equal to color
            code++; // increment the code variable to increase by 1 so loop continues
        }
    }
}

// gets random color from the range of enum members
int getColor() {
    int color = (rand() % COLORS);
    return color;
}

// passes an integer as an parameter/argument (interchangeable for this specific function)
void convertColor(int color) {
    if (color == 0) {
        printf("Black ");
    }
    else if (color == 1) {
        printf("Green ");
    }
    else if (color == 2) {
        printf("Navy ");
    }
    else if (color == 3) {
        printf("Orange ");
    }
    else if (color == 4) {
        printf("Pink ");
    }
    else if (color == 5) {
        printf("Red ");
    }
    else if (color == 6) {
        printf("Violet ");
    }
    else {
        printf("White ");
    }
}

// fills array with corresponding characters of the colors
void populateColorArray(char colors[COLORS]) {
    int color;
    for (color = 0; color < COLORS; color++) {
        if (color == 0) {
            colors[color] = 'B';
        }
        else if (color == 1) {
            colors[color] = 'G';
        }
        else if (color == 2) {
            colors[color] = 'N';
        }
        else if (color == 3) {
            colors[color] = 'O';
        }
        else if (color == 4) {
            colors[color] = 'P';
        }
        else if (color == 5) {
            colors[color] = 'R';
        }
        else if (color == 6) {
            colors[color] = 'V';
        }
        else {
            colors[color] = 'W';
        }
     }
 }

// sets each element of the guesses array to -1
void initializeArray(int guesses[TEN][FOUR]) {
    int row, col;
    for (row = 0; row < TEN; row++) {
        for (col = 0; col < FOUR; col++) {
            guesses[row][col] = -1;
        }
    }
}

// iterates through guessing values until valid ones are entered
void getGuess(int guesses[TEN][FOUR], char colors[COLORS]) {
    static int row = 0;
    int col;
    int valid = FALSE;
    char guess[TEN];

    printf("\nCharacter colors are\n");
    for (col = 0; col < COLORS; col++) {
        printf("%c ", colors[col]);
    }

    while (valid == FALSE) {
        printf("\nEnter your guess of four colors (no spaces, no duplicates):\n");
        // changes message to users to specify no duplicates
        scanf("%s", guess);
        printf("\nYou entered %s\n", guess);
        if (strlen(guess) == FOUR) {
            for (col = ZERO; col < FOUR; col++) {
                guess[col] = toupper(guess[col]);
                if (isalpha(guess[col])) {
                    if (isValid(colors, guess[col]) && !(isDuplicate(guess))) {
                    // loop runs only if the user-entered letters aren't duplicates and if they're valid guesses
                        guesses[row][col] = guess[col];
                        if (col == THREE) {
                            valid = TRUE;
                        }
                    }
                    else {
                        printf("getGuess: Invalid value entered %c, try again\n", guess[col]);
                        valid = FALSE;
                        break;
                    }
                }
                else {
                    printf("The character %c you entered isn't a letter, try again\n", guess[col]);
                    valid = FALSE;
                    break;
                }
            }
        }
        else {
            printf("getGuess: Incorrect number of letters entered\n");
            valid = FALSE;
        }
    }

    row++;
}

// checks if letters are part of the letter options in the colors array
int isValid(char colors[COLORS], char color) {
    int c;
    int valid = FALSE;
    for (c = 0; c < COLORS; c++) {
        if (color == colors[c]) {
            return TRUE;
        }
    }
    return FALSE;
}

// checks if user-entered letters are duplicates
int isDuplicate(char guess[TEN]) {
// returns type integer and parameter of guess array
    int row;
    int col;
    // below loop loops through guess array
    for (row = ZERO; row < FOUR; row++) {
        for (col = row+1; col < FOUR; col++) {
            if (guess[row] == guess[col]) {
                return TRUE;
            } // runs if duplicate is found
        }
    }
    return FALSE; // otherwise returns false
}

void getClues(int guesses[TEN][FOUR], int clues[TEN][FOUR], int secretCode[FOUR], char colors[COLORS]) {
// returns void with all necessary parameters
    static int row = ZERO;
    int redPegs = ZERO;
    int whitePegs = ZERO;
    int idx;
    int col;
    // declarations for local variables
    for (col = ZERO; col < FOUR; col++) {
    // iterates through secret code
        idx = INVALID; // initializes idx to invalid
        idx = searchArray(guesses, colors[secretCode[col]], row);
        // sets idx equal to function call with correct parameters
        if (idx == col) {
            redPegs++;
        } // runs when color is in correct location and increments redPegs
        else if ((idx != INVALID) && (idx != col)) {
            whitePegs++;
        } // runs if idx isn't invalid and if it isn't equal to col, incrementing whitePegs
    }
    evaluatePegs(redPegs, whitePegs, clues); // evaluatePegs function call
    row++; // increments row up by 1
}

int searchArray(int guesses[TEN][FOUR], char color, int row) {
// returns type integer with necessary parameters
    int idx = INVALID; // declares idx as invalid
    int col; // looping variable
    for (col = ZERO; col < FOUR; col++) {
        if(guesses[row][col] == (int)color) {
            idx = col;
        } // runs if the cast of color is equal to the current row and column in guesses
    }
    return idx; // function returns idx
}

void evaluatePegs(int red, int white, int clues[TEN][FOUR]) {
// returns type void with necessary parameters
    static int row = ZERO; // declares static row initialized to 0
    int col; // column variable
    if (red > ZERO) { // runs if value of red is larger than 0
        for (col = ZERO; col < red; col++) {
            clues[row][col] = 'R';
        } // looping construct iterates through red pegs and sets clues row and column to R
    }
    if (white > ZERO) { // runs if value of white is larger than 0
        for (col = red; col < (red+white); col++) {
            clues[row][col] = 'W';
        }
    } // looping construct iterates through white pegs and sets clues row and column to W
    row++; // increments row
}

// checks whether or not the user has won
int checkWin(int clues[TEN][FOUR]) {
    static int row = ZERO;
    int count = ZERO;
    for (int col = ZERO; col < FOUR; col++) {
        if (clues[row][col] == 'R') {
            count++;
        } // increments count if element of clues is R
    }
    row++; // increments row
    if (count == FOUR) {
        return TRUE;
    } // returns true if count equals 4
    else {
        return FALSE;
    } // otherwise, returns false
}
