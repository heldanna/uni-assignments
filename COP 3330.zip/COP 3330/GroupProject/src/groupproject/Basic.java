package groupproject;

import java.util.Scanner;

// Class for basic calculator functions, as in ones you would see on a calculator
public class Basic {
    Scanner input = new Scanner(System.in);
    double[] array = new double[100]; // array to hold digits
    int size = 0; // how many digits that will be added, subtracted, etc
    
    public Basic() {
    }
    
    public double add() {
        double sum = 0;
        System.out.print("Enter number of digits to add: ");
        size = input.nextInt();
        System.out.print("Enter digits: ");
        for (int i = 0; i < size; i++)
            array[i] = input.nextDouble(); // populates array with digits to be added together
        for (int i = 0; i < size; i++)
            sum += array[i]; // adds values in array together
        return sum;
    }
    
    public double subtract() {
        double diff;
        System.out.print("Enter number of digits to subtract: ");
        size = input.nextInt();
        System.out.print("Enter digits: ");
        for (int i = 0; i < size; i++)
            array[i] = input.nextDouble();
        diff = array[0]; // numbers will be subtracted starting from 1st value
        for (int i = 1; i < size; i++)
            diff -= array[i]; // same thing as addition except for subtracting
        return diff;
    }
    
    public double multiply() {
        double product;
        System.out.print("Enter number of digits to multiply: ");
        size = input.nextInt();
        System.out.print("Enter digits: ");
        for (int i = 0; i < size; i++)
            array[i] = input.nextDouble();
        product = array[0];
        for (int i = 1; i < size; i++)
            product *= array[i];
        return product;
    }
    
    public double divide() {
        double quotient;
        System.out.print("Enter number of digits to divide: ");
        size = input.nextInt();
        System.out.print("Enter digits: ");
        for (int i = 0; i < size; i++)
            array[i] = input.nextDouble();
        quotient = array[0];
        for (int i = 1; i < size; i++)
            quotient /= array[i];
        return quotient;
    }
    
    public double exp() {
        double result, base, exponent;
        System.out.print("Enter the base number: ");
        base = input.nextDouble();
        System.out.print("Enter the exponent: ");
        exponent = input.nextDouble();
        result = Math.pow(base, exponent); // uses Math class to calculate exponent
        return result;
    }
    
    public double root() {
        double result, num;
        System.out.print("Enter the number: ");
        num = input.nextDouble();
        result = Math.sqrt(num);
        return result;
    }
    
    public double logarithm() {
        double result, num;
        System.out.print("Enter the number: ");
        num = input.nextDouble();
        result = Math.log10(num);
        return result;
    }
    
    public double absolute() {
        double result, num;
        System.out.print("Enter the number: ");
        num = input.nextDouble();
        result = Math.abs(num);
        return result;
    }
    
    public double slope() {
        double x1, y1, x2, y2, s;
        System.out.println("Enter the values of point 1's coordinates: ");
        // prompts user to enter just coordinate numbers, not parentheses and commas in coordinate form
        x1 = input.nextDouble();
        y1 = input.nextDouble();
        System.out.println("Enter the values of point 2's coordinates: ");
        x2 = input.nextDouble();
        y2 = input.nextDouble();
        s = (y2 - y1) / (x2 - x1); // calculates slope of the two points
        return s;
    }
}