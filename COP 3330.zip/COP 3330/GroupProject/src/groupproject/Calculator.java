package groupproject;

/**
 * @authors Naomi Mbwambo and Heldanna Solomon
 * @version 4/6/22
*/
import java.util.Scanner;

// Class that contains main and menu functions from which the whole calculator runs
class Calculator {
    public static void main(String[] args) {
        menu();
        System.out.println("Thanks for using our calculator! :)"); // goodbye message to user
    }
    
    public static void menu() { // menu to run entire calculator
        Scanner input = new Scanner(System.in);
        int yesOrNo = 1; // variable to allow us to loop the function as long as the user wants
        while (yesOrNo != 0) {
            System.out.println("Welcome to our calculator! Which function would you like to use?");
	    System.out.println("1: Addition");
	    System.out.println("2: Subtraction");
	    System.out.println("3: Multiplication");
	    System.out.println("4: Division");
	    System.out.println("5: Exponents");
	    System.out.println("6: Square Roots");
	    System.out.println("7: Logarithms");
	    System.out.println("8: Sine");
	    System.out.println("9: Cosine");
	    System.out.println("10: Tangent");
	    System.out.println("11: Secant");
	    System.out.println("12: Cosecant");
	    System.out.println("13: Cotangent");
	    System.out.println("14: Absolute Value");
	    System.out.println("15: Digits of Irrational Numbers");
	    System.out.println("16: Slope of two points");
	    System.out.println("17: Displacement");
	    System.out.println("18: Final velocity");
	    System.out.println("19: Stop using calculator");
	    int answer = input.nextInt();
	    switch(answer) {
                case 1:
                    Basic addition = new Basic(); // instance of an object to call its class's function
                    System.out.println(addition.add()); // calls and prints function
                    break;
                case 2:
                    Basic sub = new Basic();
                    System.out.println(sub.subtract());
                    break;
                case 3:
                    Basic mult = new Basic();
                    System.out.println(mult.multiply());
                    break;
                case 4:
                    Basic div = new Basic();
                    System.out.println(div.divide());
                    break;
                case 5:
                    Basic exponent = new Basic();
                    System.out.println(exponent.exp());
                    break;
                case 6:
                    Basic sqrt = new Basic();
                    System.out.println(sqrt.root());
                    break;
                case 7:
                    Basic log = new Basic();
                    System.out.println(log.logarithm());
                    break;
                case 8:
                    Trig s = new Trig();
                    System.out.println(s.sine());
                    break;
                case 9:
                    Trig c = new Trig();
                    System.out.println(c.cosine());
                    break;
                case 10:
                    Trig t = new Trig();
                    System.out.println(t.tangent());
                    break;
                case 11:
                    Trig sc = new Trig();
                    System.out.println(sc.secant());
                    break;
                case 12:
                    Trig csc = new Trig();
                    System.out.println(csc.cosecant());
                    break;
                case 13:
                    Trig cotan = new Trig();
                    System.out.println(cotan.cotangent());
                    break;
                case 14:
                    Basic abv = new Basic();
                    System.out.println(abv.absolute());
                    break;
                case 15:
                    Irrational irr = new Irrational();
                    System.out.println("Which irrational number do you want to print?");
                    System.out.println("1: e");
                    System.out.println("2. pi");
                    System.out.println("3. the golden ratio (phi)");
                    int answer2 = input.nextInt();
                    System.out.println("How many digits do you want to print?");
                    int numDigits = input.nextInt();
                    switch(answer2) {
                        case 1:
                            System.out.println(irr.getE(numDigits));
                            break;
                        case 2:
                            System.out.println(irr.getPi(numDigits));
                            break;
                        case 3:
                            System.out.println(irr.getPhi(numDigits));
                            break;
                    }
                    break;
                case 16:
                    Basic slp = new Basic();
                    System.out.println(slp.slope());
                    break;
                case 17:
                    Physics p = new Physics();
                    System.out.println(p.displace());
                    break;
                case 18:
                    Physics velocity = new Physics();
                    System.out.println(velocity.vf());
                    break;
                case 19:
                    yesOrNo = 0;
                    break;
            }
        }
        input.close();
    }  
}