package groupproject;

import java.util.Scanner;

// Class that holds strings of the irrational numbers and returns their substring
public class Irrational {
    Scanner input = new Scanner(System.in);
    
    public Irrational() {
    }
    
    public String getE(int num) {
        String result;
        String e = "2.7182818284590452353602874713526624977572470936999595749669676277240766303535475945713821785251664274"; // first 100 digits of e
        result = e.substring(0, num + 1); // num + 1 to account for string using . as one of the values in the substring
        return result;
    }
    
    public String getPi(int num) {
        String result;
        String pi = "3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679";
        result = pi.substring(0, num + 1);
        return result;
    }
    
    public String getPhi(int num) {
        String result;
        String phi = "1.618033988749894848204586834365638117720309179805762862135448622705260462818902449707207204189391137";
        result = phi.substring(0, num + 1);
        return result;
    }
}