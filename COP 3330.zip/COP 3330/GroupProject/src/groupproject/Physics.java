package groupproject;

import java.util.Scanner;

// Class that calculates the diplacement and final velocity formulas from physics
public class Physics {
    Scanner input = new Scanner(System.in);
    public Physics() {
    }

    // Calculates the displacement with the given velocity, time, and acceleration
    public double displace() {
    double v, t, a, displacement;
        System.out.println("Enter velocity");
        v = input.nextDouble();
        System.out.println("Enter time");
        t = input.nextDouble();
        System.out.println("Enter acceleration");
        a = input.nextDouble();
        displacement = (v * t) + (0.5 * a * Math.pow(t,2)); // kinematic equation for displacement
        return displacement;
    }

    // Calculates the final velocity given the initial velocity, acceleration, and time
    public double vf() {
        double iv, a, t, fv;
        System.out.println("Enter initial velocity");
        iv = input.nextDouble();
        System.out.println("Enter time");
        t = input.nextDouble();
        System.out.println("Enter acceleration");
        a = input.nextDouble();
        fv = iv + (a * t);
        return fv;
    }
}