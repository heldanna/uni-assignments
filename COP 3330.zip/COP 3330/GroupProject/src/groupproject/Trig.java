package groupproject;

import java.util.Scanner;

// Class for all the trigonometric functions
public class Trig {
    Scanner input = new Scanner(System.in);
    public Trig() {
    }
    
    public double sine() {
        double result;
        double num;
        System.out.print("Enter the number: ");
        num = input.nextDouble();
        result = Math.sin(num); // uses Math class to calculate sin of given number
        return result;
    }
    
    public double cosine() {
        double result;
        double num;
        System.out.print("Enter the number: ");
        num = input.nextDouble();
        result = Math.cos(num);
        return result;
    }
    
    public double tangent() {
        double result;
        double num;
        System.out.print("Enter the number: ");
        num = input.nextDouble();
        result = Math.tan(num);
        return result;
    }
    
    public double secant() {
        double result;
        double num;
        System.out.print("Enter the number: ");
        num = input.nextDouble();
        result = 1 / (Math.cos(num)); // sec = 1/cos
        return result;
    }
    
    public double cosecant() {
        double result;
        double num;
        System.out.print("Enter the number: ");
        num = input.nextDouble();
        result = 1 / (Math.sin(num));
        return result;
    }
    
    public double cotangent() {
        double result;
        double num;
        System.out.print("Enter the number: ");
        num = input.nextDouble();
        result = 1 / Math.tan(num);
        return result;
    }
}