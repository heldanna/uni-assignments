/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package heldannasolomon_hw1_q1;
/**
 * @author Heldanna Solomon
 * @version 1/23/2022
 */

import java.util.*;
// imports Java's utility class

public class Q1 {
    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        /**
         * main function within which all expectations for Q1 are fulfilled
         */
        System.out.print("Enter a value for feet: ");
        // prompts user to enter value
        Scanner question = new Scanner(System.in);
        // creates object of class Scanner to read user input
        String valueFt = question.nextLine();
        // variable created for user input
        double valFt = Double.parseDouble(valueFt);
        // converts user input to double
        double valMet = valFt * 0.305;
        // converts user value from feet to meters by multiplying feet by .305
        System.out.println(valFt + " feet is " + valMet + " meters.");
        // prints output string
    }
    
}
