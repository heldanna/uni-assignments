/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package heldannasolomon_hw1_q2;
/**
 * @author Heldanna Solomon
 * @version 1/23/2022
 */

import java.util.*;
// imports Java's utility class

public class Q2 {
    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        /**
         * main function within which all expectations for Q2 are fulfilled
         */
        System.out.print("Enter a number between 0 and 1000: ");
        // prompts user to enter value
        Scanner question = new Scanner(System.in);
        // creates object of class Scanner to read user input
        int num = question.nextInt();
        // variable created for user input
        int sum = 0; // initializes variable sum
        while(num > 0) {
            // loop runs while the user's number is greater than 0
            int digit = num % 10;
            // gets the last digit of the user's number
            sum += digit;
            // adds that digit to the sum
            num /= 10;
            // divides the number by 10 to move through the digits of the number
        }
        System.out.println("The sum of the digits is " + sum);
        // prints output string
    }
    
}