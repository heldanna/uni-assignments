/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package heldannasolomon_hw1_q3;
/**
 * @author Heldanna Solomon
 * @version 1/23/2022
 */

import java.util.*;
// imports Java's utility class

public class Q3 {
    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        /**
         * main function within which all expectations for Q2 are fulfilled
         */
        System.out.print("Enter v0, v1, and t: ");
        // prompts user to enter values
        Scanner question = new Scanner(System.in);
        // creates object of class Scanner to read user input
        double v0 = question.nextDouble();
        double v1 = question.nextDouble();
        double t = question.nextDouble();
        // variables created for user inputs
        double avgAcc = (v1 - v0) / t;
        // calculates acceleration from user's inputs
        double round = (double)Math.round(avgAcc * 10000d) / 10000d;
        // rounds answer to 4 decimal places
        System.out.println("The average acceleration is " + round);
        // prints output string
    }
    
}