/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package heldannasolomon_hw1_q4;
/**
 * @author Heldanna Solomon
 * @version 1/23/2022
 */

import java.util.*;
// imports Java's utility class

public class Q4 {
    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        /**
         * main function within which all expectations for Q1 are fulfilled
         */
        System.out.print("Enter the monthly saving amount: ");
        // prompts user to enter value
        Scanner question = new Scanner(System.in);
        // creates object of class Scanner to read user input
        double firVal = question.nextDouble();
        // variable created for user input
        double monthOne = firVal * 1.00417;
        // calculates account's value after the first month of interest
        double monthTwo = (firVal + monthOne) * 1.00417;
        double monthThr = (firVal + monthTwo) * 1.00417;
        double monthFou = (firVal + monthThr) * 1.00417;
        double monthFiv = (firVal + monthFou) * 1.00417;
        double accVal = (firVal + monthFiv) * 1.00417;
        /*
        ...and so forth until the sixth month.
        I only calculated the account value this weird way because of the
        note in the assignment directions, which asked us not to use a loop.
        */
        double round = (double)Math.round(accVal * 100d) / 100d;
        // rounds answer to 2 decimal places
        System.out.println("After the sixth month, the account value is $" + round);
        // prints output string
    }
    
}