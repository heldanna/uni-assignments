/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package heldannasolomon_hw1_q5;
/**
 * @author Heldanna Solomon
 * @version 1/23/2022
 */

import java.util.*;
// imports Java's utility class

public class Q5 {
    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        /**
         * main function within which all expectations for Q1 are fulfilled
         */
        System.out.print("Enter the temparature in Fahrenheit between -58°F and 41°F: ");
        // prompts user to enter value
        Scanner question1 = new Scanner(System.in);
        // creates object of class Scanner to read user input
        double ta = question1.nextDouble();
        // variable created for user's first input
        System.out.print("Enter the wind speed (>=2) in miles per hour: ");
        // prompts user to enter value
        Scanner question2 = new Scanner(System.in);
        // creates another object of class Scanner to read user's second input
        double windSpeed = question2.nextDouble();
        // variable created for user's second input
        double v016 = Math.pow(windSpeed, 0.16);
        // calculates the value of v^0.16 using Math.pow(a,b)
        double twc = 35.74 + 0.6215 * ta - 35.75 * v016 + 0.4275 * ta * v016;
        // calculates wind-chill temperature using given formula
        double round = (double)Math.round(twc * 100000d) / 100000d;
        // rounds answer to 5 decimal places
        System.out.println("The wind chill index is " + round);
        // prints output string
    }
    
}