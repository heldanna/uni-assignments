/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package heldannasolomon_hw1_q6;
/**
 * @author Heldanna Solomon
 * @version 1/23/2022
 */

import java.util.*;
// imports Java's utility class

public class Q6 {
    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        /**
         * main function within which all expectations for Q1 are fulfilled
         */
        System.out.print("Enter investment amount: ");
        // prompts user to enter value
        Scanner question1 = new Scanner(System.in);
        // creates object of class Scanner to read user input
        double invAmt = question1.nextDouble();
        // variable created for user's first input
        System.out.print("Enter annual interest rate in percentage: ");
        // prompts user to enter value
        Scanner question2 = new Scanner(System.in);
        // creates another object of class Scanner to read user's second input
        double intRate = question2.nextDouble();
        // variable created for user's second input
        System.out.print("Enter number of years: ");
        // prompts user to enter value
        Scanner question3 = new Scanner(System.in);
        // creates another object of class Scanner to read user's third input
        double numYrs = question2.nextDouble();
        // variable created for user's third input
        double invVal = invAmt * Math.pow((1 + intRate / 100), (12 * numYrs));
        // calculates future investment value using given formula and exponent using Math.pow(a,b)
        double round = (double)Math.round(invVal * 100d) / 100d;
        // rounds answer to 2 decimal places
        System.out.println("Future value is $" + round);
        // prints output string
    }
    
}