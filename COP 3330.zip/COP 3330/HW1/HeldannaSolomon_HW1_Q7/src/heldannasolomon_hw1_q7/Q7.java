/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package heldannasolomon_hw1_q7;
/**
 * @author Heldanna Solomon
 * @version 1/23/2022
 */

import java.util.*;
// imports Java's utility class

public class Q7 {
    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        /**
         * main function within which all expectations for Q1 are fulfilled
         */
        System.out.print("Enter the coordinates of three points separated by spaces like x1 y1 x2 y2 x3 y3: ");
        // prompts user to enter values
        Scanner question = new Scanner(System.in);
        // creates object of class Scanner to read user input
        double x1 = question.nextDouble();
        double y1 = question.nextDouble();
        double x2 = question.nextDouble();
        double y2 = question.nextDouble();
        double x3 = question.nextDouble();
        double y3 = question.nextDouble();
        // variables created for user inputs of coordinates
        double side1 = Math.hypot(x2-x1, y2-y1);
        double side2 = Math.hypot(x3-x2, y3-y2);
        double side3 = Math.hypot(x1-x3, y1-y3);
        // calculates the distance between each of the 3 points to determine the triangle's side lengths
        double s = (side1 + side2 + side3) / 2;
        // calculates s using given formula
        double area = Math.sqrt(s * (s-side1) * (s-side2) * (s-side3));
        // calculates area using given formula and the square root function
        double round = (double)Math.round(area * 10d) / 10d;
        // rounds answer to 2 decimal places
        System.out.println("The area of the triangle is " + round);
        // prints output string
    }
    
}