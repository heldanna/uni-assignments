package heldannasolomon_hw2_q1;
/**
 * @author Heldanna Solomon
 * @version 1/30/2022
 */

import java.util.*;
// imports Java's utility package

public class Q1 {
    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        /**
         * main function within which all expectations for Q1 are fulfilled
         */
        System.out.print("Enter a, b, c, d, e, f: ");
        // prompts user to enter values
        Scanner question = new Scanner(System.in);
        // creates object of class Scanner to read user input
        double a = question.nextDouble();
        double b = question.nextDouble();
        double c = question.nextDouble();
        double d = question.nextDouble();
        double e = question.nextDouble();
        double f = question.nextDouble();
        // variables created for user inputs
        double x = (e*d - b*f) / (a*d - b*c);
        // calculates x from given equation
        double y = (a*f - e*c) / (a*d - b*c);
        // calculates y from given equation
        if ((a*d - b*c) == 0) 
            System.out.println("The equation has no solution.");
         // prints "no solution" statement if ad-bc=0
        else {
            double roundx = (double)Math.round(x * 10d) / 10d;
            // rounds x to 2 decimal places
            double roundy = (double)Math.round(y * 10d) / 10d;
            // rounds y to 2 decimal places
            System.out.println("x is " + roundx + " and y is " + roundy);
            // prints output string
        } // otherwise, runs else statement
    }    
}
