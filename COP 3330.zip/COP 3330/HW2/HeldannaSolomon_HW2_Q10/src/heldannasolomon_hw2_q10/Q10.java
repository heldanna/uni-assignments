package heldannasolomon_hw2_q10;
/**
 * @author Heldanna Solomon
 * @version 1/30/2022
 */

import java.util.*;
// imports Java's utility package

public class Q10 {
    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        /**
         * main function within which all expectations for Q10 are fulfilled
         */
        System.out.println("Enter employee's name: ");
        // prompts user to enter SSN
        Scanner question = new Scanner(System.in);
        // creates object of class Scanner to read user input
        String name = question.nextLine();
        // assigns input to a variable of type string
        System.out.println("Enter number of hours worked in a week: ");
        Scanner q2 = new Scanner(System.in);
        int hours = q2.nextInt();
        System.out.println("Enter hourly pay rate: ");
        Scanner q3 = new Scanner(System.in);
        double payRate = q3.nextDouble();
        System.out.println("Enter federal tax withholding rate: ");
        Scanner q4 = new Scanner(System.in);
        double fedTax = q4.nextDouble();
        System.out.println("Enter state tax withholding rate: ");
        Scanner q5 = new Scanner(System.in);
        double stateTax = q5.nextDouble();
        
        System.out.println("Employee name: " + name);
        System.out.println("Hours Worked: " + hours);
        System.out.println("Pay rate: S" + payRate);
        System.out.println("Gross Pay: S" + hours * payRate);
        System.out.println("Deductions: ");
        double fedHold = (hours * payRate) * fedTax;
        // calculates federal deduction
        double roundFed = (double)Math.round(fedHold * 100d) / 100d;
        // rounds the federal deduction to 2 decimal points
        System.out.println("\tFederal Withholding (" + (fedTax * 100) + "%): $" + roundFed);
        double stateHold = (hours * payRate) * stateTax;
        double roundState = (double)Math.round(stateHold * 100d) / 100d;
        System.out.println("\tState Withholding (" + (stateTax * 100) + "%): $" + roundState);
        System.out.println("\tTotal Deduction: $" + (roundFed + roundState));
        System.out.println("Net Pay: $" + ((hours * payRate) - (roundFed + roundState)));
        // net pay is the amount earned minus the deductions
    }
}