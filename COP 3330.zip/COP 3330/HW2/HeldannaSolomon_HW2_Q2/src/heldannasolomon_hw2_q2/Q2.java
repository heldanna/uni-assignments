package heldannasolomon_hw2_q2;
/**
 * @author Heldanna Solomon
 * @version 1/30/2022
 */

import java.util.*;
// imports Java's utility package

public class Q2 {
    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        /**
         * main function within which all expectations for Q2 are fulfilled
         */
        System.out.print("Enter the first 9 digits of an ISBN as integer: ");
        // prompts user to enter values
        Scanner question = new Scanner(System.in);
        // creates object of class Scanner to read user input
        String ans = question.nextLine();
        // reads the user's input as a string
        char[] c = new char[ans.length()];
        // creates an array of characters with a size the length of the user's input
        for (int i = 0; i < ans.length(); i++)
        // loop runs until the array is finished
            c[i] = ans.charAt(i);
        // loop populates the created array with the individual digits of the user's input
        int d1 = Integer.parseInt(String.valueOf(c[0]));
        int d2 = Integer.parseInt(String.valueOf(c[1]));
        int d3 = Integer.parseInt(String.valueOf(c[2]));
        int d4 = Integer.parseInt(String.valueOf(c[3]));
        int d5 = Integer.parseInt(String.valueOf(c[4]));
        int d6 = Integer.parseInt(String.valueOf(c[5]));
        int d7 = Integer.parseInt(String.valueOf(c[6]));
        int d8 = Integer.parseInt(String.valueOf(c[7]));
        int d9 = Integer.parseInt(String.valueOf(c[8]));
        /*
        converts the character values to integers.
        all of this was done to prevent any leading zeros from being neglected
        in the checksum's calculation, since Java ignores them automatically.
        */
        int checksum = (d1 + d2*2 + d3*3 + d4*4 + d5*5 + d6*6 + d7*7 + d8*8 + d9*9) % 11;
        // calculates checksum using given formula
        if (checksum == 10) {
            String check = "X";
            System.out.println("The ISBN-10 number is " + d1 + d2 + d3 + d4 + d5 + d6 + d7 + d8 + d9 + check);
        } // if checksum = 10, prints ISBN-10 number with an X at the end
        else
            System.out.println("The ISBN-10 number is " + d1 + d2 + d3 + d4 + d5 + d6 + d7 + d8 + d9 + checksum);
        // otherwise, just prints the calculated checksum
    }    
}