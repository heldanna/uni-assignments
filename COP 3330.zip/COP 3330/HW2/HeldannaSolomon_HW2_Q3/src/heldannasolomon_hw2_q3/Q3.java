package heldannasolomon_hw2_q3;
/**
 * @author Heldanna Solomon
 * @version 1/30/2022
 */

import java.util.*;
// imports Java's utility package

public class Q3 {
    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        /**
         * main function within which all expectations for Q3 are fulfilled
         * I want to note that I got most of this from the lottery code in Ch. 3
         * and only modified it to apply to 3 digit instead of 2 digit numbers.
         */
        
        // Generate a lottery
        int lowerBound = 100;
        /*
        creates variable for the lower bound onto which we will add the random number.
        this is so the random number will for sure be 3 digits.
        */
        int lottery = lowerBound + (int)(Math.random() * 900);
        
        // Prompt the user to enter a guess
        Scanner input = new Scanner(System.in);
        System.out.print("Enter your lottery pick (three digits): ");
        int guess = input.nextInt();
        
        // Get digits from lottery
        int lotteryDigit1 = lottery / 100;
        // finds 100s place digit
        int lotteryDigit2 = (lottery / 10) % 10;
        // finds 10s place digit
        int lotteryDigit3 = lottery % 100;
        // finds 1s place digit
        
        // Get digits from guess
        int guessDigit1 = guess / 100;
        int guessDigit2 = (guess / 10) % 10;
        int guessDigit3 = guess % 10;
        
        System.out.println("The lottery number is " + lottery);
        
        // Check the guess
        if (guess == lottery)
            System.out.println("Exact match: you win $10,000!");
        else if (guessDigit3 == lotteryDigit1 && guessDigit3 == lotteryDigit2
                && guessDigit2 == lotteryDigit1 && guessDigit2 == lotteryDigit3
                && guessDigit1 == lotteryDigit2 && guessDigit1 == lotteryDigit3)
            System.out.println("Match all digits: you win $3,000!");
        // prints if all the digits in the guess match those of the lottery number but are in the wrong order
        else if (guessDigit1 == lotteryDigit1 || guessDigit1 == lotteryDigit2
                || guessDigit1 == lotteryDigit3 || guessDigit2 == lotteryDigit1
                || guessDigit2 == lotteryDigit2 || guessDigit2 == lotteryDigit3
                || guessDigit3 == lotteryDigit1 || guessDigit3 == lotteryDigit2
                || guessDigit3 == lotteryDigit3)
            System.out.println("Match one digit: you win $1,000!");
        // prints if any digit in the guess matches any in the lottery number
        else
            System.out.println("Sorry, no match :(");
        // prints when none of the digits match
    }
}