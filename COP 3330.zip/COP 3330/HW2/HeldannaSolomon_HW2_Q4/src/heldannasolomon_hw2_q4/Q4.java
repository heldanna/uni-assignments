package heldannasolomon_hw2_q4;
/**
 * @author Heldanna Solomon
 * @version 1/30/2022
 */

import java.util.*;
// imports Java's utility package

public class Q4 {
    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        /**
         * main function within which all expectations for Q4 are fulfilled
         */
        System.out.print("scissor (0), rock (1), paper (2): ");
        // prompts user to enter values
        Scanner question = new Scanner(System.in);
        // creates object of class Scanner to read user input
        int rps = question.nextInt();
        // variable for user input
        int comp = (int)(Math.random() * 3);
        // generates a random number from 0-2
        if (rps == comp)
        // runs when the user entry and computer generated number are the same (draw)
            if (rps == 0)
                System.out.println("The computer is scissor. You are scissor too. It is a draw");
            // 0 = scissors so if one equals 0, both do
            else if (rps == 1)
                System.out.println("The computer is rock. You are rock too. It is a draw");
            else
                System.out.println("The computer is paper. You are paper too. It is a draw");
        else if (rps == 0 && comp == 1)
            System.out.println("The computer is rock. You are scissor. You lose");
        else if (rps == 0 && comp == 2)
            System.out.println("The computer is paper. You are scissor. You win");
        else if (rps == 1 && comp == 0)
            System.out.println("The computer is scissor. You are rock. You win");
        else if (rps == 1 && comp == 2)
            System.out.println("The computer is paper. You are rock. You lose");
        else if (rps == 2 && comp == 0)
            System.out.println("The computer is scissor. You are paper. You lose");
        else if (rps == 2 && comp == 1)
            System.out.println("The computer is rock. You are paper. You win");
    } // for all the rest of these I just aligned the correct responses to the matching numbers
}