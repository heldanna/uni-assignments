package heldannasolomon_hw2_q5;
/**
 * @author Heldanna Solomon
 * @version 1/30/2022
 */

import java.util.*;
import java.awt.geom.Point2D;
// imports Java's utility and geometry packages

public class Q5 {
    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        /**
         * main function within which all expectations for Q5 are fulfilled
         */
        System.out.print("Enter circle1's center x-, y-coordinates, and radius: ");
        // prompts user to enter values for circle 1
        Scanner cir1 = new Scanner(System.in);
        // creates object of class Scanner to read user input
        double xCir1 = cir1.nextDouble();
        double yCir1 = cir1.nextDouble();
        double rCir1 = cir1.nextDouble();
        // variables for user input
        System.out.print("Enter circle2's center x-, y-coordinates, and radius: ");
        // prompts user to enter values for circle 2
        Scanner cir2 = new Scanner(System.in);
        // creates another object of class Scanner to read user's 2nd inputs
        double xCir2 = cir2.nextDouble();
        double yCir2 = cir2.nextDouble();
        double rCir2 = cir2.nextDouble();
        // variables for user inputs
        double dist = Point2D.distance(xCir1, yCir1, xCir2, yCir2);
        if (dist <= Math.abs(rCir1 - rCir2))
            System.out.println("circle2 is inside circle1");
        else if (dist <= rCir1 + rCir2)
            System.out.println("circle2 overlaps circle1");
        else
            System.out.println("circle2 neither overlaps or is inside circle1");
    }
}