package heldannasolomon_hw2_q6;
/**
 * @author Heldanna Solomon
 * @version 1/30/2022
 */

import java.util.*;
// imports Java's utility package

public class Q6 {
    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        /**
         * main function within which all expectations for Q6 are fulfilled
         */
        System.out.print("Enter the coordinates of Atlanta, GA: ");
        // prompts user to enter values for Atlanta
        Scanner atl = new Scanner(System.in);
        // creates object of class Scanner to read user input
        double xAtl = atl.nextDouble();
        double yAtl = atl.nextDouble();
        // variables for user input
        System.out.print("Enter the coordinates of Orlando, FL: ");
        Scanner orl = new Scanner(System.in);
        double xOrl = orl.nextDouble();
        double yOrl = orl.nextDouble();
        System.out.print("Enter the coordinates of Savannah, GA: ");
        Scanner sav = new Scanner(System.in);
        double xSav = sav.nextDouble();
        double ySav = sav.nextDouble();
        System.out.print("Enter the coordinates of Charlotte, NC: ");
        Scanner cha = new Scanner(System.in);
        double xCha = cha.nextDouble();
        double yCha = cha.nextDouble();
        
        double area = 0.5 * Math.abs((xAtl*yOrl + xOrl*ySav + xSav*yCha + xCha*yAtl)-(yAtl*xOrl + yOrl*xSav + ySav*xCha + yCha*xAtl));
        /*
        I know the hint told us to use the formula in the lecture, but I think that one
        is too complicated for no reason. It would be way easier to just use the
        shoelace method to find this area.
        */
        System.out.println("The area enclosed by these 4 cities is " + area);
    }
}