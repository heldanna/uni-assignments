package heldannasolomon_hw2_q7;
/**
 * @author Heldanna Solomon
 * @version 1/30/2022
 */

import java.util.*;
// imports Java's utility package

public class Q7 {
    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        /**
         * main function within which all expectations for Q7 are fulfilled
         */
        System.out.print("Enter an ASCII code: ");
        // prompts user to enter value
        Scanner question = new Scanner(System.in);
        // creates object of class Scanner to read user input
        int ascii = question.nextInt();
        // assigns input to an integer variable
        char charac = (char)ascii;
        // converts that int to a character
        System.out.println("The character for ASCII code " + ascii + " is " + charac);
    } // prints character output
}