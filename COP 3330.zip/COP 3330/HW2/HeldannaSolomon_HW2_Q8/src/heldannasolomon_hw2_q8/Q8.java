package heldannasolomon_hw2_q8;
/**
 * @author Heldanna Solomon
 * @version 1/30/2022
 */

import java.util.*;
// imports Java's utility package

public class Q8 {
    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        /**
         * main function within which all expectations for Q8 are fulfilled
         */
        System.out.print("Enter a letter grade: ");
        // prompts user to enter grade
        Scanner question = new Scanner(System.in);
        // creates object of class Scanner to read user input
        char charGrade = question.next().charAt(0);
        // assigns input to a variable of type char
        if(charGrade == 'A')
            System.out.println("The numeric value for grade A is 4");
        else if(charGrade == 'B')
            System.out.println("The numeric value for grade B is 3");
        else if(charGrade == 'C')
            System.out.println("The numeric value for grade C is 2");
        else if(charGrade == 'D')
            System.out.println("The numeric value for grade D is 1");
        else if(charGrade == 'F')
            System.out.println("The numeric value for grade F is 0");
        // displays corresponding numeric value
        else // prints if the grade is an invalid one
            System.out.println(charGrade + " is an invalid grade");
    }
}