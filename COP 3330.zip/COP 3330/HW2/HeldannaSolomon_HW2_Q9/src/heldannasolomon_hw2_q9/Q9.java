package heldannasolomon_hw2_q9;
/**
 * @author Heldanna Solomon
 * @version 1/30/2022
 */

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
// imports Java's utility package

public class Q9 {
    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        /**
         * main function within which all expectations for Q9 are fulfilled
         */
        System.out.print("Enter a SSN: ");
        // prompts user to enter SSN
        Scanner question = new Scanner(System.in);
        // creates object of class Scanner to read user input
        String ssn = question.nextLine();
        // assigns input to a variable of type string
        String regex = "\\d{3}" + "-\\d{2}-" + "\\d{4}$";
        /*
        creates regex as a formatting verifier.
        the regex checks if the SSN is in the DDD-DD-DDDD format.
        */
        Pattern pat = Pattern.compile(regex);
        // compiles regex
        Matcher mat = pat.matcher(ssn);
        // runs user's SSN through matcher with regex
        if (mat.matches() == true) // runs if the two match
            System.out.println(ssn + " is a valid social security number");
        else // if they don't, SSN is invalid
            System.out.println(ssn + " is an invalid social security number");
    }
}