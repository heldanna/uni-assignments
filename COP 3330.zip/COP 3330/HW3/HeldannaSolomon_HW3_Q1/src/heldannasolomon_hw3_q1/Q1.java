package heldannasolomon_hw3_q1;
/**
 * @author Heldanna Solomon
 * @version 2/13/2022
 */

public class Q1 {
    /**
     * @param args
     */
    public static void main(String[] args) {
        /**
         * main function within which all expectations for Q1 are fulfilled
         */
        int n = 1; // numbers begin with 1
        int align = 7; // alignment is 1 less than the number of rows
        for (int row = 0; row < 8; row++) {
            for (int i = 0; i < align; i++) System.out.print("    ");
            // prints the spaces 1 less time each loop
            for (int i = 0; i < n; i++) System.out.printf("%4d", (int) Math.pow(2, i));
            // prints the numbers on the right side of the triangle
            for (int i = n - 2; i >= 0; i--) System.out.printf("%4d", (int) Math.pow(2, i));
            // prints the numbers on the left side of the triangle
            System.out.println(""); // new line
            align--; // subtracts align by 1 so the next line will be shifted to the left
            n++; // increases n so the numbers can be put to the exponent 
        }
    }
}