package heldannasolomon_hw3_q10;
/**
 * @author Heldanna Solomon
 * @version 2/13/2022
 */

import java.util.*;

public class Q10 {
    /**
     * @param uppercaseLetter
     * @return num
     */
    public static int getNumber(char uppercaseLetter) {
        int num = uppercaseLetter - '0';
        // converts the char to its actual value, not ASCII
        if (uppercaseLetter == 'a' || uppercaseLetter == 'A' || uppercaseLetter == 'b' ||
                uppercaseLetter == 'B' || uppercaseLetter == 'c' || uppercaseLetter == 'C')
            num = 2;
        else if (uppercaseLetter == 'd' || uppercaseLetter == 'D' || uppercaseLetter == 'e' ||
                uppercaseLetter == 'E' || uppercaseLetter == 'f' || uppercaseLetter == 'F')
            num = 3;
        else if (uppercaseLetter == 'g' || uppercaseLetter == 'G' || uppercaseLetter == 'h' ||
                uppercaseLetter == 'H' || uppercaseLetter == 'i' || uppercaseLetter == 'I')
            num = 4;
        else if (uppercaseLetter == 'j' || uppercaseLetter == 'J' || uppercaseLetter == 'k' ||
                uppercaseLetter == 'K' || uppercaseLetter == 'l' || uppercaseLetter == 'L')
            num = 5;
        else if (uppercaseLetter == 'm' || uppercaseLetter == 'M' || uppercaseLetter == 'n' ||
                uppercaseLetter == 'N' || uppercaseLetter == 'o' || uppercaseLetter == 'O')
            num = 6;
        else if (uppercaseLetter == 'p' || uppercaseLetter == 'P' || uppercaseLetter == 'q' || uppercaseLetter == 'Q' ||
                uppercaseLetter == 'r' || uppercaseLetter == 'R' || uppercaseLetter == 's' || uppercaseLetter == 'S')
            num = 7;
        else if (uppercaseLetter == 't' || uppercaseLetter == 'T' || uppercaseLetter == 'u' ||
                uppercaseLetter == 'U' || uppercaseLetter == 'v' || uppercaseLetter == 'V')
            num = 8;
        else if (uppercaseLetter == 'w' || uppercaseLetter == 'W' || uppercaseLetter == 'x' || uppercaseLetter == 'X' || 
                uppercaseLetter == 'y' || uppercaseLetter == 'Y' || uppercaseLetter == 'z' || uppercaseLetter == 'Z')
            num = 9;
        // all the if and else if statements make num = whatever number the letter would be on a phone
        else
            num += 0; // otherwise it stays its original value
        return num; // returns the corresponding number
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        System.out.print("Enter a string: ");
        Scanner question = new Scanner(System.in);
        String answer = question.nextLine();
        char ans[] = answer.toCharArray();
        for (int i = 0; i < ans.length; i++)
        // runs for every character in the array that the user enters
            if (ans[i] == '-') System.out.print("-");
            // if the character is a dash, just the dash string will be printed
            else System.out.print(getNumber(ans[i]));
            // otherwise the return from getNumber() will be printed
    }
}