package heldannasolomon_hw3_q2;
/**
 * @author Heldanna Solomon
 * @version 2/13/2022
 */

import java.util.*; // imports Java's utility package

public class Q2 {
    /**
     * @param args
     */
    public static void main(String[] args) {
        /**
         * main function within which all expectations for Q2 are fulfilled
         */
        System.out.print("Loan Amount: ");
        // prompts user to enter loan amount
        Scanner question = new Scanner(System.in);
        // creates object of class Scanner to read user input
        String loanString = question.nextLine();
        // assigns input to a variable of type string
        System.out.print("Number of years: ");
        // prompts user to enter number of years
        Scanner question2 = new Scanner(System.in);
        // creates object of class Scanner to read user input
        String yearString = question2.nextLine();
        // assigns input to a variable of type string
        System.out.println("Interest Rate\t\tMonthly Payment\tTotal Payment");
        // prints header line
        double loan = Double.parseDouble(loanString);
        // converts user entry of the loan to a double
        double years = Double.parseDouble(yearString);
        // same as above for the years
        for (double i = 5; i <= 8; i += 0.125) { // loop increments by .125 for each rate
               double rate = i / 100; // decimal version of percentage
               double months = years * 12;
               double power = Math.pow(1 + (rate/12), months);
               // I made this a variable because it was too complicated to keep track of in the monthpay calculation
               double monthPay = (loan * (rate/12) * power) / (power-1);
               // uses formula to determine monthly payment
               double totalPay = monthPay * years * 12;
               double month = Math.round(monthPay * 100.0) / 100.0;
               double total = Math.round(totalPay * 100.0) / 100.0;
               // rounds values to the nearest cent
               if (i == (int)i) System.out.println(i + "00%\t\t\t" + month + "\t\t\t" + total);
               // prints 2 zeroes after the percentage if it's a whole number
               else System.out.println(i + "%\t\t\t" + month + "\t\t\t" + total);
               // prints the total with tabs in between
           }
    }
}