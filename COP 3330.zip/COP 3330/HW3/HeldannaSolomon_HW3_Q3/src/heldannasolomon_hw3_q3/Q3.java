package heldannasolomon_hw3_q3;
/**
 * @author Heldanna Solomon
 * @version 2/13/2022
 */

public class Q3 {
    /**
     * @param args
     */
    public static void main(String[] args) {
        /**
         * main function within which all expectations for Q3 are fulfilled
         */
        System.out.println("i =\t\tP value"); // prints header line
        int i; // initializes j outside of the loop so it can be printed at the end
        for (i = 10000; i <= 100000; i += 10000) {
        // increments loop by 10000 so it prints the sum every 10000
            double sum = 0; // initalizes the variable for the sum
            for (double j = 1; j <= 10000; j++) {
            // runs 10000 times to get all the values that need to be added
                double p = 4 * (Math.pow(-1, j+1) / (2 * j-1));
                // equation for how to calculate pi using a sum
                sum += p; // adds the p to the sum
            }
            System.out.println(i + "\t\t" + sum);
            // prints i and the sum with tabs in between
        }
    }
}