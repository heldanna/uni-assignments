package heldannasolomon_hw3_q4;
/**
 * @author Heldanna Solomon
 * @version 2/13/2022
 */

import java.util.*; // imports Java's utility package

public class Q4 {
    /**
     * @param month, day, year
     * @return d
     */
    public static int val(int day, int month, int year) {
        int y = year - (14 - month) / 12;
        int x = y + y/4 - y/100 + y/400;
        int m = month + 12 * ((14 - month) / 12) - 2;
        int d = (day + x + (31*m)/12) % 7;
        return d;
    } /*
       * Returns a value that can help determine when the dates should enter to the next line.
       * This is an algorithm that I found when doing research on Java calendar libraries.
       */

    /**
     * @param args
     */
    public static void main(String[] args) {
        System.out.print("Enter the year: ");
        Scanner question = new Scanner(System.in);
        int year = question.nextInt();
        System.out.print("Enter an integer for the day that your year began. 1 for Monday, 2 for Tuesday, etc.: ");
        Scanner question2 = new Scanner(System.in);
        int firstDay = question2.nextInt();
        String[] months = {"January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"};
        // array of months of the year
        int[] days = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        // array of days each month has
        if ((year % 4 == 0) && ((year % 100 != 0) || (year % 400 == 0))) days[1] = 29;
        // checks if the year entered is a leap year; if so, February will have 
        for (int i = 0; i < 12; i++) {
        // loops for every month of the year
            System.out.println(); // prints a new line before each month's calendar
            System.out.println("\t\t " + months[i] + " " + year);
            // prints out first line of each month's calendar with its month and year
            System.out.println("------------------------------------------------"); // dividing line for style
            System.out.println("  Sun\t Mon\tTue\tWed\tThu\tFri\tSat"); // prints days of the week
            int d = val(firstDay+1, i, year); // calls val() method
            for (int j = 1; j <= days[i]; j++) {
            // loops for each day in the month
                System.out.printf("%6d ", j); // prints out dates
                if (((j + d) % 7 == 0) || (j == days[i])) System.out.println();
                // prints a new line at the end of each row
            }
            /*
             * After a lot of trying, I couldn't figure out how to align the first row
             * to the right instead of the left, so the calendar display is slightly off.
             * However, the calendar correctly determines the dates of each day, if you
             * mentally align the first row to the right.
             */
        }
    }
}