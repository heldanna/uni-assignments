package heldannasolomon_hw3_q5;
/**
 * @author Heldanna Solomon
 * @version 2/13/2022
 */

import java.util.*;

public class Q5 {
    /**
     * @param args
     */
    public static void main(String[] args) {        
        // Below is part a) of Q5
        System.out.print("Enter a string: ");
        Scanner question = new Scanner(System.in);
        String enter = question.nextLine();
        Random r = new Random();
        // creates an object of class Random to scramble the letters
        char ent[] = enter.toCharArray();
        // puts the string of the user's input into a char array
        for (int i = 0; i < ent.length; i++) {
        // runs for the length of the array
            int j = r.nextInt(ent.length);
            // assigns j to a random index in the array
            char rand = ent[i];
            // gets the value of the array at i
            ent[i] = ent[j];
            // equates that to the value of the array at index j
            ent[j] = rand;
            // equates j to the original value, switching the characters
        }
        System.out.println(ent); // prints the array
        
        // Below is part b) of Q5
        System.out.print("Enter a string: ");
        // prompts user to enter another string
        Scanner question2 = new Scanner(System.in);
        // creates object of class Scanner to read user input
        String answer = question2.nextLine();
        char letter[] = answer.toCharArray();
        int vowel = 0;
        int consonant = 0;
        // initializes variables for the vowels and consonants and sets them equal to 0
        for (int i = 0; i < letter.length; i++) {
        // runs for the length of the letter array
            if (letter[i] == 'a' || letter[i] == 'e' || letter[i] == 'i' || letter[i] == 'o' || letter[i] == 'u')
                vowel++; // adds 1 to the vowel variable if there's a vowel at i
            else if (letter[i] == ' ') consonant += 0; // if there's a space, nothing is counted
            else consonant++; // adds a consonant
        }
        System.out.println("The number of vowels is " + vowel);
        System.out.println("The number of consonants is " + consonant); // prints results
    }
}