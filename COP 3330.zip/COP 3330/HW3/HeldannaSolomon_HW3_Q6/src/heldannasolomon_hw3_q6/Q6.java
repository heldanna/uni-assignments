package heldannasolomon_hw3_q6;
/**
 * @author Heldanna Solomon
 * @version 2/13/2022
 */

import java.util.*;

public class Q6 {
    /**
     * @param n
     * @return sum
     */
    public static int sumDigits(long n) {
        int nLength = 0;
        int sum = 0;
        // initializes length and sum variables to 0
        int num = (int)n; // converts long to int
        for (; num > 0; num /= 10, nLength++) {
            // finds the how many digits are in the number
        }
        num = (int)n; // resets value of num
        for (int i = nLength; i > 0; i--) {
            int digit = num % 10; // gets the digit
            sum += digit; // adds it to the sum
            num /= 10; // divides by 10 to get the next digit
        }
        return sum; // returns sum
    }
    
    /**
     * @param args
     */
    public static void main(String[] args) {
        System.out.print("Enter an integer: ");
        Scanner question = new Scanner(System.in);
        int num = question.nextInt();
        System.out.println("The sum of the digits is " + sumDigits(num)); // prints sum
    }
}