package heldannasolomon_hw3_q7;
/**
 * @author Heldanna Solomon
 * @version 2/13/2022
 */

public class Q7 {
    /**
     * @param celsius
     * @return fahrenheit
     */
    public static double celsiusToFahrenheit(double celsius) {
        double f = (9.0 / 5) * celsius + 32;
        // using given formula to calculate Fahrenheit
        double fahrenheit = Math.round(f * 100.0) / 100.0; // rounds to 2 digits
        return fahrenheit; // returns rounded value
    }
    
    /**
     * @param fahrenheit
     * @return celsius
     */
    public static double fahrenheitToCelsius(double fahrenheit) {
        double c = (5.0 / 9) * (fahrenheit - 32);
        // using given formula to calculate Celsius
        double celsius = Math.round(c * 100.0) / 100.0; // rounds to 2 digits
        return celsius; // returns rounded value
    }
    
    /**
     * @param args
     */
    public static void main(String[] args) {
        System.out.println("Celsius\t\tFahrenheit\t|\tFahrenheit\tCelsius"); // prints header line
        System.out.println("--------------------------------------------------------------"); // prints dividing line
        double f = 120.0; // assigns a variable to the first Fahrenheit value
        for (double c = 40.0; c >= 31.0; c--) {
        // loops through the Celsius values
            System.out.println(c + "\t\t" + celsiusToFahrenheit(c) + "\t\t|\t" + f + "\t\t" + fahrenheitToCelsius(f));
            // prints out each row of the table with tabs for styling
            f -= 10.0; // subtracts 10 from f
        }
    }
}