package heldannasolomon_hw3_q8;
/**
 * @author Heldanna Solomon
 * @version 2/13/2022
 */

public class Q8 {
    /**
     * @param year
     * @return numDays
     */
    public static int numberOfDaysInAYear(int year) {
        int numDays;
        if (year == 2000 || year == 2004 || year == 2008 || year == 2012 || year == 2016 || year == 2020)
            numDays = 366; // leap years have an extra day
        else numDays = 365; // regular number of days
        return numDays;
    }
    
    /**
     * @param args
     */
    public static void main(String[] args) {
        System.out.println("Year\tNumber of Days"); // prints header line
        for (int i = 2000; i <= 2020; i++) // loops for every year from 2000 to 2020
            System.out.println(i + "\t" + numberOfDaysInAYear(i)); // prints the year and number of days
    }
}