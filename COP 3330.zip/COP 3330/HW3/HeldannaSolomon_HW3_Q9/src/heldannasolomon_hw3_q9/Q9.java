package heldannasolomon_hw3_q9;
/**
 * @author Heldanna Solomon
 * @version 2/13/2022
 */

import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.*;

public class Q9 {
    /**
     * @param args
     */
    public static void main(String[] args) {
        System.out.print("Enter your password: ");
        Scanner question = new Scanner(System.in);
        String password = question.nextLine();
        String regex = "^(?=.{8,}).*\\d.*\\d.*$";
        /*
         * The regex sets the requirements for the password.
         * To be honest I couldn't figure out how I could make the regex make the password
         * consist of just letters and digits, but it does account for the other password rules.
        */
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(password);
        // creates pattern and matcher objects to compare the regex to the password
        if(m.matches()) System.out.println("Valid Password"); // if it matches, the password is valid
        else System.out.println("Invalid Password"); // otherwise, it's invalid
    }
}