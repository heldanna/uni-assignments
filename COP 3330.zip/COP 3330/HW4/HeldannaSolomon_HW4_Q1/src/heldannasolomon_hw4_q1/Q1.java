package heldannasolomon_hw4_q1;
/**
 * @author Heldanna Solomon
 * @version 2/27/2022
 */

import java.util.*;

public class Q1 {    
    /**
     * @param args
     */
    public static void main(String[] args) {
        int[] scores = new int[100]; // array of size 100 for max # of scores
        int count = 0; // counter for actual entered # of scores
        Scanner s = new Scanner(System.in);
        System.out.print("Enter a list of scores: ");
        for (int i = 0; i < 100; i++) {
            int score = s.nextInt();
            if (score < 0) break; // breaks loop if negative #
            scores[i] = score; // populates array
            count++; // increments count by 1
        }
        double sum = 0; // sum is a double to make it possible to divide with decimals
        for (int i = 0; i < count; i++)
            sum += scores[i]; // adds scores to sum variable
        double avg = Math.round(sum / count * 100.0) / 100.0; // calculates avg, rounding to 2 decimal places
        int aboveEqualAvg = 0;
        int belowAvg = 0; // variables for which scores were >= or < the avg
        for (int i = 0; i < count; i++) {
            if (scores[i] >= avg) aboveEqualAvg++; // adds to this variable if the score is >= the avg
            else belowAvg++; // otherwise, the score is below avg
        }
        System.out.println(aboveEqualAvg + " scores were above or equal to the average score of " + avg + ", and " + belowAvg + " scores were below that average.");
    }
}