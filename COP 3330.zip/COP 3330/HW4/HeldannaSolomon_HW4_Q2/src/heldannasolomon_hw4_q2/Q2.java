package heldannasolomon_hw4_q2;
/**
 * @author Heldanna Solomon
 * @version 2/27/2022
 */

import java.util.*;

public class Q2 {
    /**
     * @param array
     * @return smallest
     */
    public static double min(double[] array) {
        double small; // holds the small number temporarily
        for (int i = 0; i < array.length; i++) {
            for (int j = i+1; j < array.length; j++) {
            // runs through array while comparing a number and the one after it
                if (array[i] > array[j]) {
                    small = array[i];
                    array[i] = array[j];
                    array[j] = small;
                } // replaces the number in the array with a smaller one to further compare
            }
        }
        double smallest = array[0]; // the smallest number is the first one in the array
        return smallest;
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        double[] nums = new double[10]; // array to hold user's numbers
        System.out.print("Enter ten numbers: ");
        Scanner s = new Scanner(System.in);
        for (int i = 0; i < 10; i++)
            nums[i] = s.nextDouble(); // populates array
        System.out.println("The minimum number is: " + min(nums)); // prints smallest number
    }
}