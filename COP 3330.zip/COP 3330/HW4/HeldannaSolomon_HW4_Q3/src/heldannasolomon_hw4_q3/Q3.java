package heldannasolomon_hw4_q3;
/**
 * @author Heldanna Solomon
 * @version 2/27/2022
 */

import java.util.*;

public class Q3 {
    
    /**
     * @param list
     * @param key
     * @return i
     */
    public static int linearSearch(int[] list, int key) {
        // linear search method from the book
        for (int i = 0; i < list.length; i++)
            if (key == list[i]) return i;
        return -1;
    }
    
    /**
     * @param list
     * @param key
     * @return mid
     */
    public static int binarySearch(int[] list, int key) {
        // binary search method from the book
        int low = 0;
        int high = list.length - 1;
        while (high >= low) {
            int mid = (low + high) / 2;
            if (key < list[mid]) high = mid - 1;
            else if (key == list[mid]) return mid;
            else low = mid + 1;
        }
        return -low - 1;
    }

    /**
     * @param list
     */
    public static void selectionSort(int[] list) {
        // array-sorting method from book
        for (int i = 0; i < list.length - 1; i++) {
            int currentMin = list[i];
            int currentMinIndex = i;
            for (int j = i + 1 ; j < list.length; j++) {
                if (currentMin > list[j]) {
                    currentMin = list[j];
                    currentMinIndex = j;
                }
            }
            if (currentMinIndex != i) {
                list[currentMinIndex] = list[i];
                list[i] = currentMin;
            }
        }
    }
    
    /**
     * @param args
     */
    public static void main(String[] args) {
        Random r = new Random();
        int[] ints = new int[100000];
        for (int i = 0; i < ints.length; i++)
            ints[i] = r.nextInt(); // populates array with 100,000 random numbers
        int key = r.nextInt(); // generates random number as the key
        long startTime = System.currentTimeMillis();
        linearSearch(ints, key); // calls linear search method to measure time
        long endTime = System.currentTimeMillis();
        long executionTime = endTime - startTime; // given to us as the way to measure execution time
        System.out.println("The execution time of invoking the linearSearch method is approximately " + executionTime + " millisecond(s).");
        selectionSort(ints); // the sorting is what takes the longest
        long startTime2 = System.currentTimeMillis();
        binarySearch(ints, key);
        long endTime2 = System.currentTimeMillis();
        long executionTime2 = endTime2 - startTime2; // but the execution times are 1 millisecond or less when I test my code
        System.out.println("The execution time of invoking the binarySearch method is approximately " + executionTime2 + " millisecond(s).");
    }
}