package heldannasolomon_hw4_q4;
/**
 * @author Heldanna Solomon
 * @version 2/27/2022
 */

import java.util.*;

public class Q4 {
    /**
     * @param args
     */
    public static void main(String[] args) {
        System.out.print("Enter the number of balls to drop: ");
        Scanner s = new Scanner(System.in);
        int numBalls = s.nextInt();
        System.out.print("Enter the number of slots in the ball machine: ");
        int numSlots = s.nextInt();
        int[] slots = new int[numSlots]; // array of slots, size is number of slots user enters
        Random r = new Random(); // creates object of class random
        int countR = 0; // variable to count the number of Rs since they're used as the index placer
        for (int i = 0; i < numSlots; i++)
            slots[i] = 0; // initializes the slots to be 0
        for (int i = 0; i < numBalls; i++) {
            for (int j = 0; j < numSlots; j++) {
                int leftOrRight = r.nextInt(2); // random number either 0 or 1
                if (leftOrRight == 0) System.out.print("L");
                else {
                    System.out.print("R");
                    countR++; // adds to countR to indicate Rs were counted
                }
            }
            slots[countR]++; // indicates a ball was put into the slots array at the index that corresponds with the number of Rs counted
            System.out.println(); // prints a new line
            countR = 0; // resets countR
        }
        
        String[] histogram = new String[numSlots]; // creates an array for the histogram
        for (int i = numBalls; i > 0; i--) {
            for (int j = 0; j < numSlots; j++) {
                if (i == slots[j]) {
                    histogram[j] = "O"; // places the O in the correct histogram slot
                    slots[j]--; // subtracts that ball from the slot
                }
                else histogram[j] = " "; // prints spaces so the Os can be aligned
                System.out.print(histogram[j]); // prints histogram
            }
            System.out.println();
        }
    }
}