package heldannasolomon_hw4_q5;
/**
 * @author Heldanna Solomon
 * @version 2/27/2022
 */

import java.util.*;

public class Q5 {
    
    /**
     * @param list1
     * @param list2
     * @return true, false
     */
    public static boolean equals(int[] list1, int[] list2) {
        if (list1.length != list2.length) return false; // if the arrays aren't equal lengths, they aren't strictly identical
        for (int i = 0; i < list1.length; i++)
            if (list1[i] != list2[i]) return false; // if any of the values in the arrays don't correspond, the arrays aren't identical
        return true; // otherwise, they are identical
    }
    
    /**
     * @param args
     */
    public static void main(String[] args) {
        System.out.print("Enter list1: ");
        Scanner s = new Scanner(System.in);
        int numElements = s.nextInt();
        int[] list1 = new int[numElements]; // creates array of correct size
        for (int i = 0; i < numElements; i++)
            list1[i] = s.nextInt(); // populates array
        System.out.print("Enter list2: ");
        int numElements2 = s.nextInt();
        int[] list2 = new int[numElements2];
        for (int i = 0; i < numElements2; i++)
            list2[i] = s.nextInt(); // same as above
        boolean equalOrNot = equals(list1, list2); // runs method to see if they're equal
        if (equalOrNot == true) System.out.println("Two lists are strictly identical");
        else System.out.println("Two lists are not strictly identical");
    }
}