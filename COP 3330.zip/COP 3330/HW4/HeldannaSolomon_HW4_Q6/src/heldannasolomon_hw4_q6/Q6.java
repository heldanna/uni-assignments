package heldannasolomon_hw4_q6;
/**
 * @author Heldanna Solomon
 * @version 2/27/2022
 */

import java.util.*;

public class Q6 {
    /**
     * @param m
     * @return true, false
     */
    public static boolean isMarkovMatrix(double[][] m) {
        double[][] test = new double[3][3]; // creates test matrix to check size
        if (m.length != test.length) return false; // if matrix is wrong size, returns false
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                if (m[i][j] < 0) return false; // checks if any of the numbers in the array are negative
        return (m[0][0] + m[1][0] + m[2][0] == 1) && (m[0][1] + m[1][1] + m[2][1] == 1) && (m[0][2] + m[1][2] + m[2][2] == 1);
    } // returns whether the columns add up to 1
    /**
     * @param args
     */
    public static void main(String[] args) {
        System.out.println("Enter a 3-by-3 matrix row by row: ");
        Scanner s = new Scanner(System.in);
        double[][] matrix = new double[3][3]; // creates array of correct size
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                matrix[i][j] = s.nextDouble(); // populates array
        boolean isMarkov = isMarkovMatrix(matrix); // runs method to see if it is a Markov matrix
        if (isMarkov == true) System.out.println("It is a Markov matrix");
        else System.out.println("It is not a Markov matrix");
    }
}