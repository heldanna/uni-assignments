package heldannasolomon_hw4_q7;
/**
 * @author Heldanna Solomon
 * @version 2/27/2022
 */

import java.util.*;

public class Q7 {
    /**
     * @param m
     * @return ans
     */
    public static int[] findLargestBlock(int[][] m) {
        int row = m.length;
        int col = m.length;
        int[] ans = new int[3];
        int size = 0;
        int xCoord = 0;
        int yCoord = 0;
        int[][] matrix = new int[row][col];
        int i = 0;
        int j = 0;
        int k = 0;
        int l = 0;
        for (i = 0; i < row; ++i)
            matrix[i][0] = m[i][0];
        for (j = 0; j < col; ++j)
            matrix[0][j] = m[0][j];
        for (i = 1; i < row; ++i) {
            for (j = 1; j < col; ++j) {
                matrix[i][j] = 0;
                if (m[i][j] == 1) {
                    matrix[i][j] = Math.min(Math.min(matrix[i-1][j], matrix[i][j-1]), matrix[i-1][j-1]) + 1;
                    if (matrix[i][j] > matrix[k][l]) {
                        k = i;
                        l = j;
                    }
                }
            }
        }
        xCoord = k - (matrix[k][l] - 1);
        yCoord = l - (matrix[k][l] - 1);
        size = matrix[k][l];
        ans[0] = xCoord;
        ans[1] = yCoord;
        ans[2] = size;
        return ans;
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        System.out.print("Enter the number of rows in the matrix: ");
        Scanner s = new Scanner(System.in);
        int numRows = s.nextInt();
        int[][] matrix = new int[numRows][numRows];
        System.out.println("Enter the matrix row by row: ");
        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numRows; j++)
                matrix[i][j] = s.nextInt();
        }
        int[] ans = findLargestBlock(matrix);
        System.out.println("The maximum square submatrix is at (" + ans[0] + ", " + ans[1] +  ") with size " + ans[2]); // prints sum
    }
}