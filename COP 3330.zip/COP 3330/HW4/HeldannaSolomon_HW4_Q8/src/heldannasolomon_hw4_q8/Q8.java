package heldannasolomon_hw4_q8;
/**
 * @author Heldanna Solomon
 * @version 2/27/2022
 */

import java.util.*;

public class Q8 {
    
    public static void printBoard(char[][] board) {
        for (int row = 0; row < 6; row++) {
            System.out.print("|");
            for (int col = 0; col < 7; col++) {
                System.out.print(board[row][col]);
                System.out.print("|");
            }
            System.out.println();
        }
        System.out.println("---------------");
    }

    public static boolean canPlay(int column, char[][] board) {
        if (board[0][column] != ' ') return false;
        return true;
    }

    public static boolean isWinner(char player, char[][] board) {
        // checks if there are 4 in a row horizontally
        for (int row = 0; row < board.length; row++) {
            for (int col = 0; col < board[0].length-3; col++) {
            // 4 is the number of columns that need to match for a player to win
                if (board[row][col] == player && board[row][col+1] == player &&
                        board[row][col+2] == player && board[row][col+3] == player) return true;
            }			
        }
        // checks if there are 4 in a row vertically
        for (int row = 0; row < board.length-3; row++) {
            for(int col = 0; col < board[0].length; col++) {
                if (board[row][col] == player && board[row+1][col] == player &&
                        board[row+2][col] == player && board[row+3][col] == player) return true;
            }
        }
        // checks if there's an upward diagonal connect 4
        for (int row = 3; row < board.length; row++) {
            for (int col = 0; col < board[0].length-3; col++) {
                if (board[row][col] == player && board[row-1][col+1] == player &&
                        board[row-2][col+2] == player && board[row-3][col+3] == player) return true;
            }
        }
        // checks if there's a downward diagonal connect 4
        for (int row = 0; row < board.length-3; row++) {
            for (int col = 0; col < board[0].length-3; col++) {
                if (board[row][col] == player && board[row+1][col+1] == player &&
                        board[row+2][col+2] == player && board[row+3][col+3] == player) return true;
            }
        }
        return false;
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        char[][] board = new char[6][7];
        for (int row = 0; row < 6; row++) {
            for (int col = 0; col < 7; col++) {
                board[row][col] = ' ';
            }
        }
        int turn = 1;
        char player = 'R';
        boolean winner = false;
        while (winner == false){
            boolean validPlay = false;
            int col = 0;
            while (validPlay == false) {
                printBoard(board);
                if (player == 'R')
                    System.out.print("Drop a red disk at column (0-6): ");
                else
                    System.out.print("Drop a yellow disk at column (0-6): ");
                col = s.nextInt();
                validPlay = canPlay(col, board);
            }
            for (int row = 5; row >= 0; row--) {
                if (board[row][col] == ' ') {
                    board[row][col] = player;
                    break;
                }
            }
            winner = isWinner(player, board);
            if (player == 'R') player = 'Y';
            else player = 'R';
            turn++;
        }
        printBoard(board);
        if (winner) {
            if (player == 'R') System.out.println("The yellow player won!");
            else System.out.println("The red player won!");
        }
    }
}