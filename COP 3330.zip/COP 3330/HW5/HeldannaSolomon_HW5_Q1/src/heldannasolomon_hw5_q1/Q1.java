package heldannasolomon_hw5_q1;
/**
 * @author Heldanna Solomon
 * @version 3/27/2022
 */

import java.util.*;

public class Q1 {
    public static void main(String[] args) {
        Random r = new Random(); // creates Random object
        int[] numbers = new int[100000]; // initializing an int array for the numbers that will be sorted
        for (int i = 0; i < numbers.length; i++) numbers[i] = r.nextInt(); // populates array with 100,000 random numbers
        StopWatch time = new StopWatch(); // creates StopWatch object
        time.start(); // calls start method
        selectionSort(numbers); // sorts the numbers
        time.stop(); // stops the time
        System.out.println("The execution time of sorting 100,000 numbers using selection sort is " + time.getElapsedTime() + " milliseconds.");
    }
    public static void selectionSort(int[] list) {
        // array-sorting method from book
        for (int i = 0; i < list.length - 1; i++) {
            int currentMin = list[i];
            int currentMinIndex = i;
            for (int j = i + 1 ; j < list.length; j++) {
                if (currentMin > list[j]) {
                    currentMin = list[j];
                    currentMinIndex = j;
                }
            }
            if (currentMinIndex != i) {
                list[currentMinIndex] = list[i];
                list[i] = currentMin;
            }
        }
    }
}

class StopWatch {
    private long startTime; // private data field
    public long getStart() {
        return startTime;
    } // getter method for startTime
    private long endTime;
    public long getEnd() {
        return endTime;
    } // same but for endTime
    public StopWatch() { // no args
        startTime = System.currentTimeMillis();
    } // initializes startTime with current time
    public void start() {
        this.startTime = System.currentTimeMillis();
    } // resets to current time
    public void stop() {
        this.endTime = System.currentTimeMillis();
    } // sets endTime to current time
    public long getElapsedTime() {
        return getEnd() - getStart();
    } // returns elapsed time
}