package heldannasolomon_hw5_q2;
/**
 * @author Heldanna Solomon
 * @version 3/27/2022
 */

import java.util.*;

public class Q2 {
    public static void main(String[] args) {
        System.out.print("Enter a, b, c, d, e, f: ");
        Scanner s = new Scanner(System.in);
        double a = s.nextDouble();
        double b = s.nextDouble();
        double c = s.nextDouble();
        double d = s.nextDouble();
        double e = s.nextDouble();
        double f = s.nextDouble(); // scans user's input for all numbers
        LinearEquation math = new LinearEquation(a, b, c, d, e, f); // creates object with input numbers as argument
        if (math.isSolvable()) System.out.println("x is " + math.getX() + " and y is " + math.getY()); // prints answer if denominator != 0
        else System.out.println("The equation has no solution"); // otherwise, tells user that there's no solution
    }
}

class LinearEquation {
    private double a;
    private double b;
    private double c;
    private double d;
    private double e;
    private double f; // private data fields
    public LinearEquation(double a, double b, double c, double d, double e, double f) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
    } // constructor with arguments for all variables
    public double getA() {
        return a;
    }
    public double getB() {
        return b;
    }
    public double getC() {
        return c;
    }
    public double getD() {
        return d;
    }
    public double getE() {
        return e;
    }
    public double getF() {
        return f;
    } // the 6 getter methods
    public boolean isSolvable() {
        return a * d - b * c != 0;
    } // checks if ad-bc is 0
    public double getX() {
        return (e * d - b * f) / (a * d - b * c);
    } // returns the value of x from the equation given in instructions
    public double getY() {
        return (a * f - e * c) / (a * d - b * c);
    } // same with y
}