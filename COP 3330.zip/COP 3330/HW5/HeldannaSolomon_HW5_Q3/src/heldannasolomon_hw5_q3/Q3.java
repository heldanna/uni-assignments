package heldannasolomon_hw5_q3;
/**
 * @author Heldanna Solomon
 * @version 3/27/2022
 */

import java.util.*;

public class Q3 {
    public static void main(String[] args) {
        System.out.print("Enter the number of rows and columns in the array: ");
        Scanner s = new Scanner(System.in);
        int r = s.nextInt();
        int c = s.nextInt();
        double[][] arr = new double[r][c];
        System.out.println("Enter the array: ");
        for(int i = 0; i < arr.length; i++) {
            for(int j = 0; j < arr[0].length; j++)
                arr[i][j] = s.nextDouble();
        } // populates array
        Location max = locateLargest(arr);
        System.out.println("The location of the largest element is " + max.maxValue + " at (" + max.row + ", " + max.column + ")");
    }
    public static Location locateLargest(double[][] a) {
        return new Location(a);
    } // creates Location object
}

class Location {
    int row;
    int column;
    double maxValue;
    Location(double[][] a) {
        row = 0;
        column = 0;
        maxValue = a[0][0]; // initialized to 0
        for(int i = 0; i < a.length; i++) {
            for(int j = 0; j < a[0].length; j++) {
                if(a[i][j] > maxValue) {
                    row = i;
                    column = j;
                    maxValue = a[i][j]; // finds max value
                }
            }
        }
    }
}