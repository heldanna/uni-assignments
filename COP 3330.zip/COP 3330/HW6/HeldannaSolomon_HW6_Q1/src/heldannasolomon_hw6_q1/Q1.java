package heldannasolomon_hw6_q1;
/**
 * @author Heldanna Solomon
 * @version 4/17/2022
 */

import java.util.*;

public class Q1 {    
    /**
     * @param args
     */
    public static void main(String[] args) {
        int[] arr = new int[100]; // creates array of size 100
        Random r = new Random();
        for(int i = 0; i < arr.length; i++)
            arr[i] = r.nextInt(101); // populates array with 100 random integers
        Scanner s = new Scanner(System.in);
        System.out.println("Enter the index of the array: ");
        try { // try for try/catch exception
            System.out.println("Corresponding element value: " + arr[s.nextInt()]);
        } // prints answer in try
        catch(ArrayIndexOutOfBoundsException ex) {
            System.out.println("Out of Bounds."); // displays out-of-bounds message
        }
    }
}