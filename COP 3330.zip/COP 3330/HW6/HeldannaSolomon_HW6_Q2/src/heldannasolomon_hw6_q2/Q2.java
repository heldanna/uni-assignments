package heldannasolomon_hw6_q2;

import java.util.*;
import java.net.*;
import java.io.*;

public class Q2 {    
    public static void main(String[] args) {
        try {
            URL url = new URL("http://cs.armstrong.edu/liang/data/Lincoln.txt");
            /*
            * gets URL where the text lies
            * the output of this code is "No stream" because the txt page doesn't open
            * therefore the stream of text can't be retrieved
            */
            int numWords = 0; // counter
            try(Scanner s = new Scanner(url.openStream())) { // try for url stream
                while(s.hasNext())
                    if(Character.isLetter((s.next()).charAt(0)))
                    // if there's a first character on the next word (basically if there's a word there)
                        numWords++; // add 1 word
            } catch(IOException ex) {
                System.out.println("No stream");
            } // if IOException is caught, there's no stream in the URL
            System.out.println("Number of words: " + numWords);
            /*
            * print output, number of words in text stream
            * right now the output is 0 because the IOException is caught for this link
            */
        } catch(MalformedURLException ex) {
            System.out.println("Invalid URL.");
        } // if URL isn't in the right format for a URL
    }
}