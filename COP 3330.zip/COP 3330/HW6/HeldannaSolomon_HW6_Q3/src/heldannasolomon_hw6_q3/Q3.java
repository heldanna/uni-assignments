package heldannasolomon_hw6_q3;

import java.util.*;
import java.io.*;

public class Q3 {    
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter directory name: ");
        File direct = new File(s.next()); // creates file with entered name of directory
        if(direct.mkdir()) // uses mkdirs method to check if directory was created
            System.out.println("Directory created successfully!");
        else System.out.println("Directory already exists");
    }
}