package heldannasolomon_midterm;
/**
 * @author Heldanna Solomon
 * @version 3/4/2022
 */

import java.util.*;

public class Midterm {
    
    public static int findDistinctCount(int[] arr) {
        int distinctCount = 0;
        int i, j;        
        for (i = 0; i < arr.length; i++) {
            for (j = 0; j < i; j++)
                if (arr[i] == arr[j])
                    break;
            if (i == j)
                distinctCount++;
        }
        return distinctCount;
    }
    
    public static int[] findDistinctNums(int[] arr, int n) {
        int[] distinct = new int[arr.length];
        int i, j;
        for (i = 0; i < arr.length; i++) {
            for (j = 0; j < i; j++)
                if (arr[i] == arr[j])
                    break;
            if (i == j)
                distinct[i] = arr[i];
        }
        return distinct;
    }
    
    public static void main(String[] args) {
        int[] numArray = new int[10];
        System.out.print("Enter ten numbers: ");
        Scanner s = new Scanner(System.in);
        for (int i = 0; i < numArray.length; i++)
            numArray[i] = s.nextInt();
        int distCount = findDistinctCount(numArray);
        System.out.println("The number of distinct numbers is " + distCount);
        int[] distArray = findDistinctNums(numArray, distCount);
        System.out.print("The distinct numbers are: ");
        for (int i = 0; i < numArray.length; i++) {
            if (distArray[i] == 0) System.out.print("");
            else System.out.print(distArray[i] + ",");
        }
        System.out.print("\nBelow 20%: ");
        System.out.print("");
    }
}