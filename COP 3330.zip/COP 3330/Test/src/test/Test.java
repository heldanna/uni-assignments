
package test;

import java.util.*;
import java.io.*;

class A {
  public A() {
    System.out.println("AA");
    }
}

class B extends A {
  public B() {
    System.out.println("BB");
    }
}

public class Test {
  public static void main(String[] args) {
    B b = new B();
    System.out.println("CC");
  }
}
