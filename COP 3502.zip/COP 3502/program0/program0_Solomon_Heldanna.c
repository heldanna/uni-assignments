#include <stdio.h>
#include <stdlib.h>

int main() {
    printf("The current month is January.\n");
    printf("The current year is 2022.\n");
    printf("I am a student at the University of Central Florida.\n");
    printf("This Spring 2022, I am taking COP3502C Computer Science 1 with Dr. Steinberg.\n");
    printf("I am super excited to learn foundational CS topics this semester!\n");
    return 0;
}
