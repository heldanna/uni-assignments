//Heldanna Solomon
//Dr. Steinberg
//COP3502 Spring 2022
//Programming Assignment 3

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct card_s{
	int rank;    //number
	char * type; //type of card
	struct card_s * nextptr;
}card_t;

//function prototypes
void rules(); //display rules
int playRound(); //simulate round
card_t * openCardDeck(); //open the card deck and place into a linkedlist setup
card_t * insertBackSetup(card_t *node, char *name, int cardrank); //take card from orginial deck and place in back of linked list for setup of game
int empty(card_t * node); //check to see if linked list is empty
void cleanUp(card_t * head); //free memory to prevent memory leaks
int deckSize(card_t * head); //count number of nodes in the linked list
card_t * search(card_t * node, int spot); //search list for a specific spot in the card deck indexing is similar to array setup
card_t * copyCard(card_t * node); //make a deep copy of card
card_t * removeCard(card_t * node, int spot); //remove card from linkedlist
card_t * insertBackDeck(card_t *head, card_t *node); //place card at end of pile
int compareCard(card_t * cardp1, card_t * cardp2); //compare cards
card_t * moveCardBack(card_t *head); //place card at top of deck to the bottom of the deck

int main()
{
	int seed;
	printf("Enter Seed: ");
	scanf("%d", &seed);

	srand(seed); //seed set
	rules();

	int player; //1 or 2
	int result;

	printf("Would you like to be player 1 or 2?\n");
	printf("Enter 1 or 2: ");
	scanf("%d", &player); //choose player

	for(int game = 1; game <= 5; ++game) //simulate games
	{
		printf("Alright lets play game %d.\n", game);
		printf("Lets split the deck.\n");

		result = playRound(); //play game

		if((result == 1 && player == 1) || (result == 2 && player == 2)) //determine who won
			printf("You won game %d.\n", game);
		else
			printf("I won game %d.\n", game);
	}

	return 0;
}

void rules()
{
	printf("Welcome to the card game war!\n");
	printf("Here are the rules.\n");
	printf("You have a pile of cards and I have a pile of cards.\n");
	printf("We will each pull the top card off of our respective deck and compare them.\n");
	printf("The card with the highest number will win the round and take both cards.\n");
	printf("However if there is a tie, then we have to we have to place one card faced down and the next one faced up and compare the results.\n");
	printf("Winner of the tie, will grab all the cards out. However if it's a tie again, then we repeat the same action.\n");
	printf("Ready? Here we go!\n");
}

card_t * openCardDeck()
{
	FILE *fptr = fopen("deck.txt", "r");

	char *name = (char *) malloc(sizeof(char) * 20);

	if (name == NULL)
	{
		printf("Error in malloc...\n");
		exit(1);
	}

	card_t * head = NULL;

	int cardrank = 13;
	int tracker = 1;
	while(fscanf(fptr, "%s", name) == 1)
	{
		strcat(name, " ");

		if(tracker % 5 == 1)
		{
			strcat(name, "of Clubs");
			head = insertBackSetup(head, name, cardrank);
		}
		else if(tracker % 5 == 2)
		{
			strcat(name, "of Diamonds");
			head = insertBackSetup(head, name, cardrank);
		}
		else if(tracker % 5 == 3)
		{
			strcat(name, "of Hearts");
			head = insertBackSetup(head, name, cardrank);
		}
		else if(tracker % 5 == 4)
		{
			strcat(name, "of Spades");
			head = insertBackSetup(head, name, cardrank);
			tracker = 0;
			--cardrank;
		}

		++tracker;

	}

	free(name);
	fclose(fptr);

	return head;
}

card_t * insertBackSetup(card_t *node, char *name, int cardrank)
{

    if(empty(node)) //check to see if list is empty
    {
		node = (card_t *) malloc(sizeof(card_t));

		if(empty(node)) //check to see if malloc worked
		{
			printf("Did not allocate head successfully...");
			printf("Program Terminating...\n");
			exit(1);
		}
		else //otherwise populate data of new head node
		{
			node->type = (char *) malloc(sizeof(char) * 20);

			if(node->type == NULL)
			{
				printf("Error with malloc...\n");
				exit(1);
			}

			strcpy(node->type, name);
			node->rank = cardrank;
			node->nextptr = NULL; //must make new tail nextptr NULL!!!

			return node;  //terminate
		}

    }

	//here we know that the list has at least one node

	card_t *head = node; //keep pointer to head since we will need to return this address

	while(node->nextptr != NULL) //traverse to tail
		node = node->nextptr;

	node->nextptr = (card_t *) malloc(sizeof(card_t));

	if(node->nextptr == NULL) //see if new tail was allocated successfully
	{
		printf("Did not allocate node successfully...");
		return head; //terminate if tail didn't get created
	}

	//populate new node
	node->nextptr->type = (char *) malloc(sizeof(char) * 20);

	if(node->nextptr->type == NULL)
	{
		printf("Error with malloc...\n");
		exit(1);
	}

	strcpy(node->nextptr->type, name);
	node->nextptr->rank = cardrank;
	node->nextptr->nextptr = NULL; //very important

	return head; //return head node since we need our starting point of the linked list
}

int empty(card_t * node)
{
	return (node == NULL); //return condition result
}

/// Below are all the functions I wrote.

int playRound() {
	card_t * deck = openCardDeck(); // opens deck that we'll use for the game
    int numCards = deckSize(deck); // number of cards in the deck
	card_t * player1 = NULL;
	card_t * player2 = NULL; // linked list of cards for both players is empty
	printf("There are %d cards in the deck.\n", numCards);
	// the following while loop populates the players' list of cards
	while(numCards > 0) { // runs while there are still cards
       int r = rand() % numCards; // picks a random number
       card_t * card = copyCard(search(deck, r)); // retrieves the card at that spot
	   if(numCards % 2 == 1) player1 = insertBackDeck(player1, card);
       else if(numCards % 2 == 0) player2 = insertBackDeck(player2, card); // cards fill each player's deck back and forth
       deck = removeCard(deck, r); // removes the added card from the deck
       --numCards; // increments down so the while loop can end once numCards hits 0
	}
	// the following while loop runs the game
	while(deckSize(player1) < 52 && deckSize(player2) < 52) { // runs only if both players don't yet have a full deck
        int whoWon = compareCard(player1, player2); // determines which scenario plays out
        printf("Player 1 pulled out %s. \t Player 2 pulled out %s.\n", player1->type, player2->type);
        if(whoWon != 0) printf("Player %d won that round.\n", whoWon); // runs if there's no tie
        if(whoWon == 1) {
            player1 = moveCardBack(player1); // the card is moved to the back of player 1's deck
            player1 = insertBackDeck(player1, copyCard(player2)); // player 2's card is put at the end of player 1's deck
            player2 = removeCard(player2, 0); // 1st card removed from player 2's deck
        } // occurs if player 1 wins the round
        else if(whoWon == 2) {
            player2 = moveCardBack(player2);
            player2 = insertBackDeck(player2, copyCard(player1));
            player1 = removeCard(player1, 0);
        } // same as above but for player 2
		else if(whoWon == 0) {
            int numTies = 1; // counts the number of ties to be able to correctly print how many cards each player has during each tie
            card_t * warCards = NULL; // linked list of the cards the winner of the war will get
            while(whoWon == 0) { // runs when there's a tie
                if(numTies > 1) printf("Player 1 has %d cards.\nPlayer 2 has %d cards.\n", deckSize(player1), deckSize(player2)); // prints each time there's a tie
                printf("Ugh oh...We have a tie! W-A-R!\n");
                if(deckSize(player1) == 1) {
                    player2 = insertBackDeck(player2, copyCard(player1));
                    return 2;
                }
                else if(deckSize(player2) == 1) {
                    player1 = insertBackDeck(player1, copyCard(player2));
                    return 1;
                }
                /*
                 * if either player has only 1 card left in their deck during war,
                 * the other player wins the game and takes their card
                 * this is because the war can't be properly played without >2 cards
                 */
                else if (deckSize(player1) == 2 || deckSize(player2) == 2) {
                    warCards = insertBackDeck(warCards, copyCard(player1));
                    player1 = removeCard(player1, 0);
                    warCards = insertBackDeck(warCards, copyCard(player2));
                    player2 = removeCard(player2, 0);
                }
                /*
                 * if either player has only 2 cards during war,
                 * only 1 of their cards will be entered into the deck of cards that the winner of the war will get
                 */
                else {
                    warCards = insertBackDeck(warCards, copyCard(player1));
                    player1 = removeCard(player1, 0); // player 1's faced up card
                    warCards = insertBackDeck(warCards, copyCard(player1));
                    player1 = removeCard(player1, 0); // player 1's face down card
                    warCards = insertBackDeck(warCards, copyCard(player2));
                    player2 = removeCard(player2, 0); // player 2's faced up card
                    warCards = insertBackDeck(warCards, copyCard(player2));
                    player2 = removeCard(player2, 0); // player 2's face down card
                } // if neither player has <= 2 cards, they can each put 1 card face up and another other face down
                printf("Player 1 pulled out %s. \t Player 2 pulled out %s.\n", player1->type, player2->type); // prints the type of the head of the players' decks
                ++numTies; // increments numTies so if there's another tie and the loop loops again, the players' number of cards will be printed
                whoWon = compareCard(player1, player2); // checks who won after the new cards were pulled out
            }
            warCards = insertBackDeck(warCards, copyCard(player1));
            player1 = removeCard(player1, 0);
            warCards = insertBackDeck(warCards, copyCard(player2));
            player2 = removeCard(player2, 0);
            // same thing as within the loop but for the last cards of the war
            printf("Player %d won that W-A-R!\n", whoWon); // prints who won the war
            card_t * card; // no assignment, because it will be assigned with either player 1 or player 2's deck
            if(whoWon == 1) {
                if(player1 != NULL) {
                    card = player1;
                    while(card->nextptr != NULL) card = card->nextptr;
                    card->nextptr = warCards;
                }
                else player1 = warCards; // if player 1's deck is empty, their deck is the same as the warCards one
            } // if player 1 wins the war, the cards are added to their deck
            else if(whoWon == 2) {
                if(player2 != NULL) {
                    card = player2;
                    while (card->nextptr != NULL) card = card->nextptr;
                    card->nextptr = warCards;
                }
                else player2 = warCards;
            } // same as above but for player 2
        } // finally, the end of the loop for each game
        printf("Player 1 has %d cards.\nPlayer 2 has %d cards.\n", deckSize(player1), deckSize(player2)); // prints the deck sizes
        if(deckSize(player2) == 0) return 1; // player 1 wins when player 2 has no cards left
        if(deckSize(player1) == 0) return 2; // and vice versa
    }
    cleanUp(player1);
    cleanUp(player2);
    cleanUp(deck); // cleans up the entire game
}

void cleanUp(card_t * head) {
	card_t * card = head; // variable for head of list
    while(card != NULL) {
        card_t * temp = card;
        free(temp->type); // frees card's type
        free(temp); // frees the card
        card = card->nextptr; // moves to next card
    }
}

int deckSize(card_t * head) {
    int numCards = 0;
    card_t * card = head;
    if(head == NULL) return 0; // no cards in deck if head is null
    while(card != NULL) {
        card = card->nextptr;
        ++numCards;
    } // counts number of cards
    return numCards;
}

card_t * search(card_t * node, int spot) {
    card_t * card = node; // where function begins searching
    for(int i = 0; i < spot; ++i) card = card->nextptr; // goes through list to the desired spot
    return card; // returns the card in the correct spot
}

card_t * copyCard(card_t * node) {
    card_t * copy = (card_t *) malloc(sizeof(card_t)); // using malloc the same way as in insertBackSetup()
    char *type = (char *) malloc(sizeof(char) * 20); // using malloc the same way as in openCardDeck()
    copy->rank = node->rank; // assigns the node's rank to the copy
    strcpy(type, node->type); // copies node's type into the dynamic string
    copy->type = type; // copy's type is the result of the strcpy
    return copy;
}

card_t * removeCard(card_t * node, int spot) {
    if(spot == 0) {
        card_t * head = node->nextptr; // if spot==0, the node is at the top of the list, so its nextptr is the new head
        free(node->type);
        free(node); // frees memory of removed card and its type
        return head;
    }
    card_t * cardBefore = node;
    for(int i = 1; i < spot; ++i) cardBefore = cardBefore->nextptr; // goes to card preceding the one that needs to be removed
    card_t * card = cardBefore->nextptr; // card that'll be removed
    cardBefore->nextptr = cardBefore->nextptr->nextptr; // makes sure the card following the one preceding the one that was removed is the one after the one that was removed
    free(card->type);
    free(card); // frees memory of removed card and its type
    return node;
}

card_t * insertBackDeck(card_t *head, card_t *node) {
    card_t * card = head;
    if(head == NULL) {
        node->nextptr = head; // the nextptr is null like the head
        return node;
    } // runs if there are no cards in the deck
    while(card->nextptr != NULL) card = card->nextptr; // goes to end of deck
    card_t * backCard = card; // the back card is the result of the while loop
    backCard->nextptr = node; // the card after it is the node
    backCard->nextptr->nextptr = NULL; // the card after that is null because it's the end of the list
    return head;
}

int compareCard(card_t * cardp1, card_t * cardp2) {
    if(cardp1->rank > cardp2->rank) return 1; // player 1 wins
    else if(cardp1->rank < cardp2->rank) return 2; // player 2 wins
    else if(cardp2->rank == cardp1->rank) return 0; // W-A-R
}

card_t * moveCardBack(card_t *head) {
    card_t * card = head;
    card_t * newHead = head->nextptr; // next card in list is the new head
    while(card->nextptr != NULL) card = card->nextptr; // goes to end of deck
    card->nextptr = head; // old head becomes the new last card
    card->nextptr->nextptr = NULL; // there is no card after the new last card
    return newHead;
}
