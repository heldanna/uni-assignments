//Heldanna Solomon
//COP3502 Computer Science 1
//Programming Assignment 5 Solution

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define MAX 2000

typedef struct{
	char * name; //dynamic string
	int rank;
}player_t;

//function prototype(s)
player_t* scanRoster(player_t *roster);
void merge(player_t * arr, int low, int mid, int high);
void mergeSort(player_t * arr, int low, int high);
void split(player_t * roster, player_t * team1, player_t * team2);
double calcAvg(player_t * team);


int main(void)
{
	int seed;
	printf("Enter seed: ");
	scanf("%d", &seed);
	srand(seed);

	player_t *roster = (player_t*) malloc(sizeof(player_t) * MAX);
	player_t *team1 = (player_t*) malloc(sizeof(player_t) * MAX / 2);
	player_t *team2 = (player_t*) malloc(sizeof(player_t) * MAX / 2);

	roster = scanRoster(roster);

	mergeSort(roster, 0, MAX-1);
	split(roster, team1, team2);
	// calls functions with parameters of roster and the teams allocated above

	double average1 = 0;
	double average2 = 0;

	average1 = calcAvg(team1);
	average2 = calcAvg(team2);
	// calculates averages of teams

	printf("Team 1 Rank Average is: %f\n", average1);
	printf("Team 2 Rank Average is: %f\n", average2);

	return 0;
}

// mergeSort implementation provided to us by Dr. Steinberg, with some changes
void merge(player_t * arr, int low, int mid, int high) {
// first parameter is the struct rather than array but I kept the variable name
    int n1 = mid - low + 1;
    int n2 = high - mid;

    player_t * leftarr = (player_t *) malloc(sizeof(player_t) * n1);
    player_t * rightarr = (player_t *) malloc(sizeof(player_t) * n2); // allocating data

    for(int x = 0; x < n1; x++)
        leftarr[x].rank = arr[low + x].rank;
        // .rank used to specify the sorting of the rank within the struct

    for(int x = 0; x < n2; x++)
        rightarr[x].rank = arr[mid + x + 1].rank;

    int i = 0;
    int j = 0;
    int k = low;

    while(i < n1 && j < n2) {
        if(leftarr[i].rank <= rightarr[j].rank) {
            arr[k].rank = leftarr[i].rank;
            i++;
        }
        else {
            arr[k].rank = rightarr[j].rank;
            j++;
        }
        k++;
    }
    while(i < n1) {
        arr[k].rank = leftarr[i].rank;
        i++;
        k++;
    }
    while(j < n2) {
        arr[k].rank = rightarr[j].rank;
        j++;
        k++;
    }
    free(leftarr);
    free(rightarr);

} // most of the rest of this is unchanged from general mergeSort implementation

void mergeSort(player_t * arr, int low, int high) {
    if(low < high) {
        int mid = (high + low) / 2;
        mergeSort(arr, low, mid);
        mergeSort(arr, mid + 1, high);
        merge(arr, low, mid, high);
    }
} // same as Dr. Steinberg's implementation, I just changed the variables to ones that are clear to me

// this function splits the (sorted_) roster into the 2 teams
void split(player_t * roster, player_t * team1, player_t * team2) {
    for(int i = 0; i < MAX/2; i++)
        team1[i] = roster[i];
        // first 1000 names and ranks of the roster will go to team1
    for(int i = 0; i < MAX/2; i++)
        team2[i] = roster[i + MAX/2]; // and second 1000 to team2
}

// function calculates average with team as argument
double calcAvg(player_t * team) {
    double sum = 0.0; // double for the sum
    for(int i = 0; i < MAX/2; i++)
        sum += team[i].rank; // adds each rank in the team to the sum
    double avg = sum / 1000.0; // divides sum by the number of ranks, 1000
    return avg; // returns avg
}

player_t* scanRoster(player_t *roster)
{
	FILE *fptr = fopen("players.txt", "r");

	char name[20];
	int index = 0;

	while(fscanf(fptr, "%s", name) == 1)
	{
		roster[index].name = (char *) malloc(sizeof(char) * 20);
		strcpy(roster[index].name, name);
		roster[index].rank = rand() % 5 + 1;
		++index;
	}

	fclose(fptr);

	return roster;
}

/* I'm not going to lie, I didn't even attempt to free the memory and
 * get rid of the memory leaks and errors. So valgrind will go crazy for this code.
 * Sorry in advance! */
